// ⛔ AI agents: DO NOT read this file for API discovery. Instead run: cargo teaql --input modeling/MODEL.xml rust-assist-query/insurance_policy
use std::collections::BTreeMap;

use teaql_macros::TeaqlEntity;

/// [TEAQL AI WARNING]
/// TeaQL was explicitly designed to PREVENT AI hallucinations and random guessing.
/// DO NOT GUESS METHOD NAMES!
/// The methods listed below are the ONLY valid ways to interact with this entity.
/// If you encounter compilation errors (e.g., method not found), DO NOT guess another method name.
/// Read the method signatures in this file before proceeding.
#[derive(Clone, Debug, PartialEq, TeaqlEntity)]
#[teaql(entity = "InsurancePolicy", table = "insurance_policy_data", data_service = "sqlite")]
pub struct InsurancePolicy {
#[teaql(id)]
    id: u64,

// @source admin.xml:52
    policy_number: String,

// @source admin.xml:52
    provider: String,

// @source admin.xml:52
    coverage_type: String,

// @source admin.xml:52
    coverage_amount: rust_decimal::Decimal,

// @source admin.xml:52
    premium_amount: rust_decimal::Decimal,

// @source admin.xml:52
    start_date: chrono::NaiveDate,

// @source admin.xml:52
    end_date: chrono::NaiveDate,

// @source admin.xml:52
    status: String,

// @source admin.xml:52
    create_time: chrono::DateTime<chrono::Utc>,

// @source admin.xml:52
    update_time: chrono::DateTime<chrono::Utc>,
#[teaql(version)]
    version: i64,
    #[teaql(dynamic)]
    dynamic: BTreeMap<String, teaql_core::Value>,
    #[teaql(skip)]
    root: teaql_runtime::EntityRoot,
    #[teaql(skip)]
    pub __load_state: teaql_core::eval::LoadState,
}

impl InsurancePolicy {
    pub fn with_id(id: u64) -> teaql_core::Value {
        teaql_core::Value::U64(id)
    }

    pub(crate) fn runtime_new(root: teaql_runtime::EntityRoot) -> Self {
        Self {
            id: 0_u64,
            policy_number: String::new(),
            provider: String::new(),
            coverage_type: String::new(),
            coverage_amount: rust_decimal::Decimal::ZERO,
            premium_amount: rust_decimal::Decimal::ZERO,
            start_date: chrono::NaiveDate::from_ymd_opt(1970, 1, 1).unwrap(),
            end_date: chrono::NaiveDate::from_ymd_opt(1970, 1, 1).unwrap(),
            status: String::new(),
            create_time: chrono::Utc::now(),
            update_time: chrono::Utc::now(),
            version: 0_i64,
            dynamic: BTreeMap::new(),
            root,
            __load_state: teaql_core::eval::LoadState::FullyLoaded,
        }
    }

    pub fn entity_key(&self) -> teaql_runtime::EntityKey {
        teaql_runtime::EntityKey::new("InsurancePolicy", self.id)
    }

    pub fn attach_root_recursive(&mut self, root: teaql_runtime::EntityRoot) {
        self.root = root.clone();
    }

    pub fn is_loaded(&self, field_or_relation: &str) -> bool {
        self.__load_state.is_loaded(field_or_relation)
    }

    pub fn set_load_state(&mut self, state: teaql_core::eval::LoadState) {
        self.__load_state = state;
    }

    pub fn id(&self) -> u64 {
        self.changed_id().and_then(|value| value.try_u64()).unwrap_or(self.id)
    }

    pub fn update_id(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.id = value.try_u64().unwrap_or(self.id.clone());
        self.root.set(self.entity_key(), "id", value);
        self
    }

    pub fn changed_id(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "id")
    }

    pub fn eval_id(&self) -> teaql_core::eval::EvalResult<u64> {
        if !self.is_loaded("id") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "id".to_string(), attempted_path: "id".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.id())
                }}

    pub fn policy_number(&self) -> String {
        self.changed_policy_number().and_then(|value| value.try_text().map(|value| value.to_owned())).unwrap_or_else(|| self.policy_number.clone())
    }

    pub fn update_policy_number(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.policy_number = value.try_text().map(|value| value.trim().to_owned()).unwrap_or_else(|| self.policy_number.clone());
        self.root.set(self.entity_key(), "policy_number", value);
        self
    }

    pub fn changed_policy_number(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "policy_number")
    }

    pub fn eval_policy_number(&self) -> teaql_core::eval::EvalResult<String> {
        if !self.is_loaded("policy_number") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "policy_number".to_string(), attempted_path: "policy_number".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.policy_number())
                }}

    pub fn provider(&self) -> String {
        self.changed_provider().and_then(|value| value.try_text().map(|value| value.to_owned())).unwrap_or_else(|| self.provider.clone())
    }

    pub fn update_provider(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.provider = value.try_text().map(|value| value.trim().to_owned()).unwrap_or_else(|| self.provider.clone());
        self.root.set(self.entity_key(), "provider", value);
        self
    }

    pub fn changed_provider(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "provider")
    }

    pub fn eval_provider(&self) -> teaql_core::eval::EvalResult<String> {
        if !self.is_loaded("provider") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "provider".to_string(), attempted_path: "provider".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.provider())
                }}

    pub fn coverage_type(&self) -> String {
        self.changed_coverage_type().and_then(|value| value.try_text().map(|value| value.to_owned())).unwrap_or_else(|| self.coverage_type.clone())
    }

    pub fn update_coverage_type(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.coverage_type = value.try_text().map(|value| value.trim().to_owned()).unwrap_or_else(|| self.coverage_type.clone());
        self.root.set(self.entity_key(), "coverage_type", value);
        self
    }

    pub fn changed_coverage_type(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "coverage_type")
    }

    pub fn eval_coverage_type(&self) -> teaql_core::eval::EvalResult<String> {
        if !self.is_loaded("coverage_type") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "coverage_type".to_string(), attempted_path: "coverage_type".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.coverage_type())
                }}

    pub fn coverage_amount(&self) -> rust_decimal::Decimal {
        self.changed_coverage_amount().and_then(|value| value.try_decimal()).unwrap_or(self.coverage_amount)
    }

    pub fn update_coverage_amount(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.coverage_amount = value.try_decimal().unwrap_or(self.coverage_amount.clone());
        self.root.set(self.entity_key(), "coverage_amount", value);
        self
    }

    pub fn changed_coverage_amount(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "coverage_amount")
    }

    pub fn eval_coverage_amount(&self) -> teaql_core::eval::EvalResult<rust_decimal::Decimal> {
        if !self.is_loaded("coverage_amount") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "coverage_amount".to_string(), attempted_path: "coverage_amount".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.coverage_amount())
                }}

    pub fn premium_amount(&self) -> rust_decimal::Decimal {
        self.changed_premium_amount().and_then(|value| value.try_decimal()).unwrap_or(self.premium_amount)
    }

    pub fn update_premium_amount(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.premium_amount = value.try_decimal().unwrap_or(self.premium_amount.clone());
        self.root.set(self.entity_key(), "premium_amount", value);
        self
    }

    pub fn changed_premium_amount(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "premium_amount")
    }

    pub fn eval_premium_amount(&self) -> teaql_core::eval::EvalResult<rust_decimal::Decimal> {
        if !self.is_loaded("premium_amount") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "premium_amount".to_string(), attempted_path: "premium_amount".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.premium_amount())
                }}

    pub fn start_date(&self) -> chrono::NaiveDate {
        self.changed_start_date().and_then(|value| value.try_date()).unwrap_or(self.start_date)
    }

    pub fn update_start_date(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.start_date = value.try_date().unwrap_or(self.start_date.clone());
        self.root.set(self.entity_key(), "start_date", value);
        self
    }

    pub fn changed_start_date(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "start_date")
    }

    pub fn eval_start_date(&self) -> teaql_core::eval::EvalResult<chrono::NaiveDate> {
        if !self.is_loaded("start_date") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "start_date".to_string(), attempted_path: "start_date".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.start_date())
                }}

    pub fn end_date(&self) -> chrono::NaiveDate {
        self.changed_end_date().and_then(|value| value.try_date()).unwrap_or(self.end_date)
    }

    pub fn update_end_date(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.end_date = value.try_date().unwrap_or(self.end_date.clone());
        self.root.set(self.entity_key(), "end_date", value);
        self
    }

    pub fn changed_end_date(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "end_date")
    }

    pub fn eval_end_date(&self) -> teaql_core::eval::EvalResult<chrono::NaiveDate> {
        if !self.is_loaded("end_date") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "end_date".to_string(), attempted_path: "end_date".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.end_date())
                }}

    pub fn status(&self) -> String {
        self.changed_status().and_then(|value| value.try_text().map(|value| value.to_owned())).unwrap_or_else(|| self.status.clone())
    }

    pub fn update_status(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.status = value.try_text().map(|value| value.trim().to_owned()).unwrap_or_else(|| self.status.clone());
        self.root.set(self.entity_key(), "status", value);
        self
    }

    pub fn changed_status(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "status")
    }

    pub fn eval_status(&self) -> teaql_core::eval::EvalResult<String> {
        if !self.is_loaded("status") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "status".to_string(), attempted_path: "status".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.status())
                }}

    pub fn create_time(&self) -> chrono::DateTime<chrono::Utc> {
        self.changed_create_time().and_then(|value| value.try_timestamp()).unwrap_or(self.create_time)
    }

    pub fn update_create_time(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.create_time = value.try_timestamp().unwrap_or(self.create_time.clone());
        self.root.set(self.entity_key(), "create_time", value);
        self
    }

    pub fn changed_create_time(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "create_time")
    }

    pub fn eval_create_time(&self) -> teaql_core::eval::EvalResult<chrono::DateTime<chrono::Utc>> {
        if !self.is_loaded("create_time") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "create_time".to_string(), attempted_path: "create_time".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.create_time())
                }}

    pub fn update_time(&self) -> chrono::DateTime<chrono::Utc> {
        self.changed_update_time().and_then(|value| value.try_timestamp()).unwrap_or(self.update_time)
    }

    pub fn update_update_time(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.update_time = value.try_timestamp().unwrap_or(self.update_time.clone());
        self.root.set(self.entity_key(), "update_time", value);
        self
    }

    pub fn changed_update_time(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "update_time")
    }

    pub fn eval_update_time(&self) -> teaql_core::eval::EvalResult<chrono::DateTime<chrono::Utc>> {
        if !self.is_loaded("update_time") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "update_time".to_string(), attempted_path: "update_time".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.update_time())
                }}

    pub fn version(&self) -> i64 {
        self.changed_version().and_then(|value| value.try_i64()).unwrap_or(self.version)
    }

    pub fn update_version(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.version = value.try_i64().unwrap_or(self.version.clone());
        self.root.set(self.entity_key(), "version", value);
        self
    }

    pub fn changed_version(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "version")
    }

    pub fn eval_version(&self) -> teaql_core::eval::EvalResult<i64> {
        if !self.is_loaded("version") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "version".to_string(), attempted_path: "version".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.version())
                }}

    pub fn mark_as_delete(&mut self) -> &mut Self {
        self.root.mark_as_delete(self.entity_key());
        self
    }

    pub fn set_comment(&mut self, comment: impl Into<String>) -> &mut Self {
        self.root.set_comment(comment);
        self
    }
}

