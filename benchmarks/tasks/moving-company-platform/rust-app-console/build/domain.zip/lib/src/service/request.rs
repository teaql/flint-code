use std::marker::PhantomData;

use serde_json::Value as JsonValue;
use teaql_core::{Aggregate, AggregateFunction, EntityDescriptor, Expr, Record, SelectQuery, SmartList};
use teaql_runtime::{DataServiceError, RuntimeError};

use crate::request_support::*;

impl EntityReference for crate::Service {
    fn entity_id_value(self) -> teaql_core::Value {
        teaql_core::IdentifiableEntity::id_value(&self)
    }
}

impl EntityReference for &crate::Service {
    fn entity_id_value(self) -> teaql_core::Value {
        teaql_core::IdentifiableEntity::id_value(self)
    }
}

// ⛔ AI agents: DO NOT read this file for API discovery. Instead run: cargo teaql --input modeling/MODEL.xml rust-assist-query/service
#[derive(Debug)]
pub struct ServiceRequest<R = crate::Service> {
    query: SelectQuery,
    relation_selections: Vec<RelationSelection>,
    relation_filters: Vec<RelationFilter>,
    child_enhancements: Vec<QuerySelection>,
    query_options: QueryOptions,
    marker: PhantomData<R>,
}

impl<R> Clone for ServiceRequest<R> {
    fn clone(&self) -> Self {
        Self {
            query: self.query.clone(),
            relation_selections: self.relation_selections.clone(),
            relation_filters: self.relation_filters.clone(),
            child_enhancements: self.child_enhancements.clone(),
            query_options: self.query_options.clone(),
            marker: PhantomData,
        }
    }
}

impl<R> ServiceRequest<R> {
    pub(crate) fn new() -> Self {
        Self {
            query: SelectQuery::new("Service")
                .project("id")
                .project("version"),
            relation_selections: Vec::new(),
            relation_filters: Vec::new(),
            child_enhancements: Vec::new(),
            query_options: QueryOptions::default(),
            marker: PhantomData,
        }
    }

    pub fn return_type<T>(self) -> ServiceRequest<T> {
        ServiceRequest {
            query: self.query,
            relation_selections: self.relation_selections,
            relation_filters: self.relation_filters,
            child_enhancements: self.child_enhancements,
            query_options: self.query_options,
            marker: PhantomData,
        }
    }

    pub fn query(&self) -> &SelectQuery {
        &self.query
    }

    pub fn relation_selections(&self) -> &[RelationSelection] {
        &self.relation_selections
    }

    pub fn relation_filters(&self) -> &[RelationFilter] {
        &self.relation_filters
    }

    pub fn child_enhancements(&self) -> &[QuerySelection] {
        &self.child_enhancements
    }

    pub fn query_options(&self) -> &QueryOptions {
        &self.query_options
    }

    pub fn into_query(self) -> SelectQuery {
        self.query
    }


    pub fn purpose(self, purpose: impl Into<String>) -> crate::PurposedQuery<Self> {
        crate::PurposedQuery::new(self, purpose)
    }

    pub(crate) async fn _execute_for_list<'a, C>(
        self,
        ctx: &'a C,
    ) -> Result<SmartList<R>, TeaqlDataServiceError<C::ServiceRepository<'a>>>
    where
        C: TeaqlRepositoryProvider + ?Sized,
        R: teaql_core::Entity,
    {
        let repository = ctx
            .service_repository()
            .map_err(|err| DataServiceError::Runtime(RuntimeError::Graph(err.to_string())))?;
        let query_options = self.query_options.clone();
        let relation_aggregates = runtime_relation_aggregates(&query_options);
        let query = authorize_query(apply_runtime_metadata(
            self.query,
            &query_options,
            &self.child_enhancements,
        )).map_err(DataServiceError::Runtime)?;
        let mut rows = repository.fetch_enhanced_entities_with_relation_aggregates::<R>(
            &query,
            &relation_aggregates,
        ).await?;
        let facets = execute_facets(ctx, query.as_query(), &query_options)
            .await
            .map_err(DataServiceError::Runtime)?;
        attach_facets(&mut rows, facets);
        Ok(rows)
    }

    pub(crate) async fn _execute_for_stream<'a, C>(
        self,
        ctx: &'a C,
    ) -> Result<Vec<teaql_data_service::StreamChunk>, TeaqlDataServiceError<C::ServiceRepository<'a>>>
    where
        C: TeaqlRepositoryProvider + ?Sized,
    {
        let repository = ctx
            .service_repository()
            .map_err(|err| DataServiceError::Runtime(RuntimeError::Graph(err.to_string())))?;
        let query_options = self.query_options.clone();
        let query = authorize_query(apply_runtime_metadata(
            self.query,
            &query_options,
            &self.child_enhancements,
        )).map_err(DataServiceError::Runtime)?;
        let chunks = repository.fetch_stream(&query)
            .await?;
        Ok(chunks)
    }

    pub(crate) async fn _execute_for_first<'a, C>(
        self,
        ctx: &'a C,
    ) -> Result<Option<R>, TeaqlDataServiceError<C::ServiceRepository<'a>>>
    where
        C: TeaqlRepositoryProvider + ?Sized,
        R: teaql_core::Entity,
    {
        let rows = self.limit(1)._execute_for_list(ctx).await?;
        Ok(rows.into_iter().next())
    }

    pub(crate) async fn _execute_for_one<'a, C>(
        self,
        ctx: &'a C,
    ) -> Result<Option<R>, TeaqlDataServiceError<C::ServiceRepository<'a>>>
    where
        C: TeaqlRepositoryProvider + ?Sized,
        R: teaql_core::Entity,
    {
        self._execute_for_first(ctx).await
    }


    pub(crate) async fn _execute_for_page<'a, C>(
        self,
        ctx: &'a C,
        offset: u64,
        limit: u64,
    ) -> Result<SmartList<R>, TeaqlDataServiceError<C::ServiceRepository<'a>>>
    where
        C: TeaqlRepositoryProvider + ?Sized,
        R: teaql_core::Entity,
    {
        let total_count = self.clone()._execute_for_count(ctx).await?;
        let mut rows = self.page_offset(offset, limit)._execute_for_list(ctx).await?;
        rows.total_count = Some(total_count);
        Ok(rows)
    }

    pub(crate) async fn _execute_for_count<'a, C>(
        self,
        ctx: &'a C,
    ) -> Result<u64, TeaqlDataServiceError<C::ServiceRepository<'a>>>
    where
        C: TeaqlRepositoryProvider + ?Sized,
    {
        let repository = ctx
            .service_repository()
            .map_err(|err| DataServiceError::Runtime(RuntimeError::Graph(err.to_string())))?;
        let mut query = self.query;
        query.projection.clear();
        query.expr_projection.clear();
        query.order_by.clear();
        query.slice = None;
        query.relations.clear();
        query = query.count(COUNT_ALIAS);
        let query = authorize_query(query).map_err(DataServiceError::Runtime)?;
        let rows = repository.fetch_all(&query).await?;
        rows.first()
            .and_then(|row| row.get(COUNT_ALIAS))
            .and_then(teaql_core::Value::try_u64)
            .ok_or_else(|| DataServiceError::Runtime(RuntimeError::Graph(format!("count result for Service is missing or not numeric"))))
    }

    pub(crate) async fn _execute_for_exists<'a, C>(
        self,
        ctx: &'a C,
    ) -> Result<bool, TeaqlDataServiceError<C::ServiceRepository<'a>>>
    where
        C: TeaqlRepositoryProvider + ?Sized,
    {
        let repository = ctx
            .service_repository()
            .map_err(|err| DataServiceError::Runtime(RuntimeError::Graph(err.to_string())))?;
        let mut query = self.query.limit(1);
        query.relations.clear();
        let query = authorize_query(query).map_err(DataServiceError::Runtime)?;
        let rows = repository.fetch_all(&query).await?;
        Ok(!rows.is_empty())
    }

    pub(crate) async fn _execute_for_records<'a, C>(
        self,
        ctx: &'a C,
    ) -> Result<SmartList<Record>, TeaqlDataServiceError<C::ServiceRepository<'a>>>
    where
        C: TeaqlRepositoryProvider + ?Sized,
    {
        let repository = ctx
            .service_repository()
            .map_err(|err| DataServiceError::Runtime(RuntimeError::Graph(err.to_string())))?;
        let query_options = self.query_options.clone();
        let outer_query = self.query.clone();
        let relation_aggregates = runtime_relation_aggregates(&query_options);
        let query = authorize_query(apply_runtime_metadata(
            self.query,
            &query_options,
            &self.child_enhancements,
        )).map_err(DataServiceError::Runtime)?;
        let mut rows = repository.fetch_smart_list_with_relation_aggregates(&query, &relation_aggregates).await?;
        let facets = execute_facets(ctx, &outer_query, &query_options)
            .await
            .map_err(DataServiceError::Runtime)?;
        attach_facets(&mut rows, facets);
        Ok(rows)
    }

    pub(crate) async fn _execute_for_record<'a, C>(
        self,
        ctx: &'a C,
    ) -> Result<Option<Record>, TeaqlDataServiceError<C::ServiceRepository<'a>>>
    where
        C: TeaqlRepositoryProvider + ?Sized,
    {
        let records = self.limit(1)._execute_for_records(ctx).await?;
        Ok(records.into_iter().next())
    }

    pub fn search_with_text(mut self, text: impl Into<String>) -> Self {
        self.query = self.query.search_with_text(text);
        self
    }

    pub fn filter(mut self, filter: Expr) -> Self {
        self.query = self.query.filter(filter);
        self
    }

    pub fn and_filter(mut self, filter: Expr) -> Self {
        self.query = self.query.and_filter(filter);
        self
    }

    pub fn or_filter(mut self, filter: Expr) -> Self {
        self.query = self.query.or_filter(filter);
        self
    }

    pub fn append_search_criteria(self, criteria: Expr) -> Self {
        self.and_filter(criteria)
    }

    pub fn filter_property(
        mut self,
        property1: impl AsRef<str>,
        operator: FieldOperator,
        property2: impl AsRef<str>,
    ) -> Self {
        self.query = self.query.and_filter(field_operator_column_expr(
            property1.as_ref(),
            operator,
            property2.as_ref(),
        ));
        self
    }

    pub fn with_deleted_rows(mut self) -> Self {
        self.query.filter = remove_default_live_filter(self.query.filter);
        self
    }

    pub fn deleted_rows_only(mut self) -> Self {
        self.query.filter = remove_default_live_filter(self.query.filter);
        self.query = self.query.and_filter(Expr::lte("version", 0_i64));
        self
    }

    pub fn match_types(
        mut self,
        types: impl IntoIterator<Item = impl Into<teaql_core::Value>>,
    ) -> Self {
        self.query = self.query.and_filter(Expr::in_list(TYPE_FIELD, types.into_iter().map(Into::into)));
        self
    }


    pub fn with_type_group(mut self) -> Self {
        self.query = self.query.project(TYPE_GROUP_FIELD);
        self
    }

    pub fn matching_any_of(mut self, request: impl Into<QuerySelection>) -> Self {
        let selection = request.into();
        let entity = EntityDescriptor::new(selection.query.entity.clone());
        self.query = self.query.and_filter(Expr::in_subquery("id", entity, selection.query.clone(), "id"));
        self
    }

    pub fn match_any_of(self, request: impl Into<QuerySelection>) -> Self {
        self.matching_any_of(request)
    }

    pub fn enhance_child(mut self, request: impl Into<QuerySelection>) -> Self {
        self.child_enhancements.push(request.into());
        self
    }

    pub fn enhance_children_if_needed(self) -> Self {
        let request = self;
        request
    }


    pub fn comment(mut self, comment: impl Into<String>) -> Self {
        self.query_options.comment = Some(comment.into());
        self
    }

    pub fn raw_sql(self, raw_sql: impl Into<String>) -> Self {
        self.unsafe_raw_sql(UnsafeRawSqlSegment::trusted(raw_sql))
    }

    pub fn unsafe_raw_sql(mut self, raw_sql: UnsafeRawSqlSegment) -> Self {
        self.query_options.raw_sql = Some(raw_sql.into_sql());
        self
    }

    pub fn raw_sql_filter(self, raw_sql: impl Into<String>) -> Self {
        self.unsafe_raw_sql_filter(UnsafeRawSqlSegment::trusted(raw_sql))
    }

    pub fn unsafe_raw_sql_filter(mut self, raw_sql: UnsafeRawSqlSegment) -> Self {
        self.query_options.raw_sql_search_criteria.push(raw_sql.into_sql());
        self
    }
    pub fn filter_with_json(self, json_expr: impl Into<String>) -> Self {
        self.merge_dynamic_json_expr(json_expr.into())
    }

    fn merge_dynamic_json_expr(self, json_expr: String) -> Self {
        let json = serde_json::from_str::<JsonValue>(&json_expr)
            .unwrap_or_else(|_| panic!("Input JSON format error: {json_expr}"));
        self.merge_dynamic_json(&json)
    }

    fn merge_dynamic_json(mut self, json: &JsonValue) -> Self {
        let Some(object) = json.as_object() else {
            return self;
        };

        for (field, value) in object {
            if field.starts_with('_') {
                continue;
            }
            self = self.apply_dynamic_json_filter(field, value);
        }

        self = self.apply_dynamic_json_order_by(object.get("_orderBy"));

        if let Some(offset) = dynamic_json_u64_field(object, "_start") {
            self = self.skip(offset);
        }
        if let Some(size) = dynamic_json_u64_field(object, "_size") {
            self = self.limit(size);
        }

        if let Some(page_size) = dynamic_json_u64_field(object, "_pageSize") {
            self = self.limit(page_size);
        }
        if let Some(page_number) = dynamic_json_u64_field(object, "_page") {
            if page_number > 0 {
                let size = dynamic_json_u64_field(object, "_pageSize")
                    .or_else(|| self.query.slice.as_ref().and_then(|slice| slice.limit))
                    .unwrap_or(10);
                let offset = page_number.saturating_sub(1).saturating_mul(size);
                self = self.page_offset(offset, size);
            }
        }

        self
    }

    pub(crate) fn apply_dynamic_json_filter(self, field: &str, value: &JsonValue) -> Self {
        if let Some((head, tail)) = field.split_once('.') {
            self.apply_dynamic_json_chain_filter(head, tail, value)
        } else if let Some(storage_field) = Self::dynamic_json_self_field(field) {
            self.and_filter(dynamic_json_filter_expr(storage_field, value))
        } else {
            self
        }
    }

    fn apply_dynamic_json_order_by(mut self, order_by: Option<&JsonValue>) -> Self {
        match order_by {
            Some(JsonValue::String(field)) => {
                if let Some(storage_field) = Self::dynamic_json_self_field(field) {
                    self.query = self.query.order_desc(storage_field);
                }
            }
            Some(JsonValue::Object(order_by)) => {
                self = self.apply_dynamic_json_single_order_by(order_by);
            }
            Some(JsonValue::Array(order_bys)) => {
                for order_by in order_bys {
                    if let Some(order_by) = order_by.as_object() {
                        self = self.apply_dynamic_json_single_order_by(order_by);
                    }
                }
            }
            _ => {}
        }
        self
    }

    fn apply_dynamic_json_single_order_by(
        mut self,
        order_by: &serde_json::Map<String, JsonValue>,
    ) -> Self {
        let Some(field) = order_by.get("field").and_then(JsonValue::as_str) else {
            return self;
        };
        let Some(storage_field) = Self::dynamic_json_self_field(field) else {
            return self;
        };
        if order_by
            .get("useAsc")
            .and_then(JsonValue::as_bool)
            .unwrap_or(false)
        {
            self.query = self.query.order_asc(storage_field);
        } else {
            self.query = self.query.order_desc(storage_field);
        }
        self
    }

    fn dynamic_json_self_field(field: &str) -> Option<&'static str> {
        match field {
            "id" => Some("id"),
            "name" => Some("name"),
            "description" => Some("description"),
            "base_price" => Some("base_price"),
            "price_per_hour" => Some("price_per_hour"),
            "is_active" => Some("is_active"),
            "create_time" => Some("create_time"),
            "update_time" => Some("update_time"),
            "version" => Some("version"),
            "service_category" | "service_category_id" => Some("service_category_id"),
            _ => None,
        }
    }

    fn apply_dynamic_json_chain_filter(self, head: &str, tail: &str, value: &JsonValue) -> Self {
        let _ = (tail, value);
        match head {
            "service_category" => {
                self.with_service_category_matching(
                    crate::Q::service_categories_minimal()
                        .apply_dynamic_json_filter(tail, value),
                )
            }
            "service_configuration_list" => {
                self.with_service_configuration_list_matching(
                    crate::Q::service_configurations_minimal()
                        .apply_dynamic_json_filter(tail, value),
                )
            }
            "pricing_rule_list" => {
                self.with_pricing_rule_list_matching(
                    crate::Q::pricing_rules_minimal()
                        .apply_dynamic_json_filter(tail, value),
                )
            }
            _ => self,
        }
    }

    pub fn create_property_as(
        self,
        property_name: impl Into<String>,
        raw_sql_segment: impl Into<String>,
    ) -> Self {
        self.unsafe_create_property_as(property_name, UnsafeRawSqlSegment::trusted(raw_sql_segment))
    }

    pub fn unsafe_create_property_as(
        mut self,
        property_name: impl Into<String>,
        raw_sql_segment: UnsafeRawSqlSegment,
    ) -> Self {
        self.query_options
            .dynamic_properties
            .push(RawDynamicProperty::new(property_name, raw_sql_segment));
        self
    }

    pub fn limit(mut self, limit: u64) -> Self {
        self.query = self.query.limit(limit);
        self
    }

    pub fn skip(mut self, offset: u64) -> Self {
        self.query = self.query.offset(offset);
        self
    }

    pub fn offset_only(self, offset: u64) -> Self {
        self.skip(offset)
    }

    pub fn offset(self, offset: u64, size: u64) -> Self {
        self.page_offset(offset, size)
    }

    pub fn page_offset(mut self, offset: u64, limit: u64) -> Self {
        self.query = self.query.page(offset, limit);
        self
    }

    pub fn top(self, top_n: u64) -> Self {
        self.limit(top_n)
    }

    pub fn offset_size(self, offset: u64, size: u64) -> Self {
        self.offset(offset, size)
    }

    pub fn unlimited(mut self) -> Self {
        self.query.slice = None;
        self
    }

    pub fn page_number(self, page_number: u64, page_size: u64) -> Self {
        let offset = page_number.saturating_sub(1).saturating_mul(page_size);
        self.page_offset(offset, page_size)
    }

    pub fn page_number_default(self, page_number: u64) -> Self {
        self.page_number(page_number, 10)
    }

    pub fn page(self, page_number: u64, page_size: u64) -> Self {
        self.page_number(page_number, page_size)
    }

    pub fn page_default(self, page_number: u64) -> Self {
        self.page_number_default(page_number)
    }

    pub fn select_self(mut self) -> Self {
        self.query = self.query.project("id");
        self.query = self.query.project("name");
        self.query = self.query.project("description");
        self.query = self.query.project("base_price");
        self.query = self.query.project("price_per_hour");
        self.query = self.query.project("is_active");
        self.query = self.query.project("create_time");
        self.query = self.query.project("update_time");
        self.query = self.query.project("version");
        self.query = self.query.project("service_category_id");
        self
    }

    pub fn select_self_fields(self) -> Self {
        self.select_self()
    }

    pub fn select_self_without_parent(self) -> Self {
        self.select_self_fields()
    }

    pub fn select_all(self) -> Self {
        let mut request = self.select_self();
        request = request.select_service_category();
        request
    }

    pub fn select_children(self) -> Self {
        let mut request = self.select_all();
        request = request.select_service_configuration_list();
        request = request.select_pricing_rule_list();
        request
    }

    pub fn select_any(self) -> Self {
        self.select_children()
    }

    pub fn group_by(mut self, field: impl Into<String>) -> Self {
        self.query = self.query.group_by(field);
        self
    }

    pub fn aggregate_count(mut self, alias: impl Into<String>) -> Self {
        self.query = self.query.count(alias);
        self
    }

    pub fn aggregate_count_field(mut self, field: impl Into<String>, alias: impl Into<String>) -> Self {
        self.query = self.query.count_field(field, alias);
        self
    }

    pub fn aggregate_with_function(
        mut self,
        field: impl Into<String>,
        alias: impl Into<String>,
        function: AggregateFunction,
    ) -> Self {
        self.query = self.query.aggregate(Aggregate::new(function, field, alias));
        self
    }

    pub fn aggregate_sum(mut self, field: impl Into<String>, alias: impl Into<String>) -> Self {
        self.query = self.query.sum(field, alias);
        self
    }

    pub fn aggregate_avg(mut self, field: impl Into<String>, alias: impl Into<String>) -> Self {
        self.query = self.query.avg(field, alias);
        self
    }

    pub fn aggregate_min(mut self, field: impl Into<String>, alias: impl Into<String>) -> Self {
        self.query = self.query.min(field, alias);
        self
    }

    pub fn aggregate_max(mut self, field: impl Into<String>, alias: impl Into<String>) -> Self {
        self.query = self.query.max(field, alias);
        self
    }

    pub fn aggregate_stddev(mut self, field: impl Into<String>, alias: impl Into<String>) -> Self {
        self.query = self.query.stddev(field, alias);
        self
    }

    pub fn aggregate_stddev_pop(mut self, field: impl Into<String>, alias: impl Into<String>) -> Self {
        self.query = self.query.stddev_pop(field, alias);
        self
    }

    pub fn aggregate_var_samp(mut self, field: impl Into<String>, alias: impl Into<String>) -> Self {
        self.query = self.query.var_samp(field, alias);
        self
    }

    pub fn aggregate_var_pop(mut self, field: impl Into<String>, alias: impl Into<String>) -> Self {
        self.query = self.query.var_pop(field, alias);
        self
    }

    pub fn aggregate_bit_and(mut self, field: impl Into<String>, alias: impl Into<String>) -> Self {
        self.query = self.query.bit_and(field, alias);
        self
    }

    pub fn aggregate_bit_or(mut self, field: impl Into<String>, alias: impl Into<String>) -> Self {
        self.query = self.query.bit_or(field, alias);
        self
    }

    pub fn aggregate_bit_xor(mut self, field: impl Into<String>, alias: impl Into<String>) -> Self {
        self.query = self.query.bit_xor(field, alias);
        self
    }

    pub fn enable_aggregation_cache(mut self) -> Self {
        self.query = self.query.enable_aggregation_cache();
        self
    }

    pub fn enable_aggregation_cache_for(mut self, cache_expired_millis: u64) -> Self {
        self.query = self.query.enable_aggregation_cache_for(cache_expired_millis);
        self
    }

    pub fn propagate_aggregation_cache(mut self, cache_expired_millis: u64) -> Self {
        self.query = self.query.propagate_aggregation_cache(cache_expired_millis);
        self
    }

    pub fn group_by_id(self) -> Self {
        self.group_by("id")
    }

    pub fn group_by_id_as(self, alias: impl Into<String>) -> Self {
        let alias = alias.into();
        let mut request = self.group_by("id");
        request.query = request
            .query
            .project_expr(alias, Expr::column("id"));
        request
    }

    pub fn group_by_id_with_function(
        self,
        alias: impl Into<String>,
        function: AggregateFunction,
    ) -> Self {
        self.group_by("id")
            .aggregate_with_function("id", alias, function)
    }

    pub fn count_id(self) -> Self {
        self.count_id_as("id_count")
    }

    pub fn count_id_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_count_field("id", alias)
    }

    pub fn sum_id(self) -> Self {
        self.sum_id_as("sum_id")
    }

    pub fn sum_id_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_sum("id", alias)
    }

    pub fn avg_id(self) -> Self {
        self.avg_id_as("avg_id")
    }

    pub fn avg_id_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_avg("id", alias)
    }

    pub fn min_id(self) -> Self {
        self.min_id_as("min_id")
    }

    pub fn min_id_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_min("id", alias)
    }

    pub fn max_id(self) -> Self {
        self.max_id_as("max_id")
    }

    pub fn max_id_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_max("id", alias)
    }


    pub fn with_id(
        mut self,
        operator: FieldOperator,
        values: impl IntoIterator<Item = impl Into<teaql_core::Value>>,
    ) -> Self {
        self.query = self.query.and_filter(field_operator_expr(
            "id",
            operator,
            values.into_iter().map(Into::into).collect(),
        ));
        self
    }

    pub fn create_id_criteria(
        operator: FieldOperator,
        values: impl IntoIterator<Item = impl Into<teaql_core::Value>>,
    ) -> Expr {
        field_operator_expr(
            "id",
            operator,
            values.into_iter().map(Into::into).collect(),
        )
    }

    pub fn with_id_is(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::eq("id", value));
        self
    }



    pub fn with_id_is_not(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::ne("id", value));
        self
    }

    pub fn with_id_in(
        mut self,
        values: impl IntoIterator<Item = impl Into<teaql_core::Value>>,
    ) -> Self {
        self.query = self.query.and_filter(Expr::in_list(
            "id",
            values.into_iter().map(Into::into),
        ));
        self
    }

    pub fn with_id_not_in(
        mut self,
        values: impl IntoIterator<Item = impl Into<teaql_core::Value>>,
    ) -> Self {
        self.query = self.query.and_filter(Expr::not_in_list(
            "id",
            values.into_iter().map(Into::into),
        ));
        self
    }

    pub fn order_by_id_asc(mut self) -> Self {
        self.query = self.query.order_asc("id");
        self
    }

    pub fn order_by_id_desc(mut self) -> Self {
        self.query = self.query.order_desc("id");
        self
    }

    pub fn order_by_id_asc_using_gbk(mut self) -> Self {
        self.query = self.query.order_gbk_asc("id");
        self
    }

    pub fn order_by_id_desc_using_gbk(mut self) -> Self {
        self.query = self.query.order_gbk_desc("id");
        self
    }


    pub fn select_name(mut self) -> Self {
        self.query = self.query.project("name");
        self
    }

    pub fn project_name(self) -> Self {
        self.select_name()
    }

    pub fn select_name_raw(self, raw_sql_segment: impl Into<String>) -> Self {
        self.select_name_unsafe_raw(UnsafeRawSqlSegment::trusted(raw_sql_segment))
    }

    pub fn select_name_unsafe_raw(mut self, raw_sql_segment: UnsafeRawSqlSegment) -> Self {
        self.query_options
            .raw_projections
            .push(RawProjection::new("name", raw_sql_segment));
        self
    }

    pub fn group_by_name(self) -> Self {
        self.group_by("name")
    }

    pub fn group_by_name_as(self, alias: impl Into<String>) -> Self {
        let alias = alias.into();
        let mut request = self.group_by("name");
        request.query = request
            .query
            .project_expr(alias, Expr::column("name"));
        request
    }

    pub fn group_by_name_with_function(
        self,
        alias: impl Into<String>,
        function: AggregateFunction,
    ) -> Self {
        self.group_by("name")
            .aggregate_with_function("name", alias, function)
    }

    pub fn count_name(self) -> Self {
        self.count_name_as("name_count")
    }

    pub fn count_name_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_count_field("name", alias)
    }

    pub fn sum_name(self) -> Self {
        self.sum_name_as("sum_name")
    }

    pub fn sum_name_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_sum("name", alias)
    }

    pub fn avg_name(self) -> Self {
        self.avg_name_as("avg_name")
    }

    pub fn avg_name_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_avg("name", alias)
    }

    pub fn min_name(self) -> Self {
        self.min_name_as("min_name")
    }

    pub fn min_name_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_min("name", alias)
    }

    pub fn max_name(self) -> Self {
        self.max_name_as("max_name")
    }

    pub fn max_name_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_max("name", alias)
    }

    pub fn unselect_name(mut self) -> Self {
        self.query.projection.retain(|field| field != "name");
        self.query_options.raw_projections.retain(|projection| projection.property_name != "name");
        self
    }


    pub fn with_name(
        mut self,
        operator: FieldOperator,
        values: impl IntoIterator<Item = impl Into<teaql_core::Value>>,
    ) -> Self {
        self.query = self.query.and_filter(field_operator_expr(
            "name",
            operator,
            values.into_iter().map(Into::into).collect(),
        ));
        self
    }

    pub fn create_name_criteria(
        operator: FieldOperator,
        values: impl IntoIterator<Item = impl Into<teaql_core::Value>>,
    ) -> Expr {
        field_operator_expr(
            "name",
            operator,
            values.into_iter().map(Into::into).collect(),
        )
    }

    pub fn with_name_is(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::eq("name", value));
        self
    }



    pub fn with_name_is_not(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::ne("name", value));
        self
    }

    pub fn with_name_greater_than(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::gt("name", value));
        self
    }

    pub fn with_name_greater_than_or_equal_to(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::gte("name", value));
        self
    }

    pub fn with_name_less_than(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::lt("name", value));
        self
    }

    pub fn with_name_less_than_or_equal_to(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::lte("name", value));
        self
    }

    pub fn with_name_between(
        mut self,
        lower: impl Into<teaql_core::Value>,
        upper: impl Into<teaql_core::Value>,
    ) -> Self {
        self.query = self.query.and_filter(Expr::between("name", lower, upper));
        self
    }

    pub fn with_name_between_range<T>(mut self, range: DateRange<T>) -> Self
    where
        T: Into<teaql_core::Value>,
    {
        self.query = self.query.and_filter(Expr::between(
            "name",
            range.start,
            range.end,
        ));
        self
    }

    pub fn with_name_in(
        mut self,
        values: impl IntoIterator<Item = impl Into<teaql_core::Value>>,
    ) -> Self {
        self.query = self.query.and_filter(Expr::in_list(
            "name",
            values.into_iter().map(Into::into),
        ));
        self
    }

    pub fn with_name_not_in(
        mut self,
        values: impl IntoIterator<Item = impl Into<teaql_core::Value>>,
    ) -> Self {
        self.query = self.query.and_filter(Expr::not_in_list(
            "name",
            values.into_iter().map(Into::into),
        ));
        self
    }

    pub fn with_name_containing(mut self, value: impl Into<String>) -> Self {
        self.query = self.query.and_filter(Expr::contain("name", value));
        self
    }

    pub fn with_name_not_containing(mut self, value: impl Into<String>) -> Self {
        self.query = self.query.and_filter(Expr::not_contain("name", value));
        self
    }

    pub fn with_name_starting_with(mut self, value: impl Into<String>) -> Self {
        self.query = self.query.and_filter(Expr::begin_with("name", value));
        self
    }

    pub fn with_name_not_starting_with(mut self, value: impl Into<String>) -> Self {
        self.query = self.query.and_filter(Expr::not_begin_with("name", value));
        self
    }

    pub fn with_name_ending_with(mut self, value: impl Into<String>) -> Self {
        self.query = self.query.and_filter(Expr::end_with("name", value));
        self
    }

    pub fn with_name_not_ending_with(mut self, value: impl Into<String>) -> Self {
        self.query = self.query.and_filter(Expr::not_end_with("name", value));
        self
    }

    pub fn with_name_sounding_like(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::sound_like("name", value));
        self
    }
    pub fn with_name_before(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::lt("name", value));
        self
    }

    pub fn with_name_after(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::gt("name", value));
        self
    }

    pub fn with_name_is_unknown(mut self) -> Self {
        self.query = self.query.and_filter(Expr::is_null("name"));
        self
    }



    pub fn with_name_is_known(mut self) -> Self {
        self.query = self.query.and_filter(Expr::is_not_null("name"));
        self
    }


    pub fn order_by_name_asc(mut self) -> Self {
        self.query = self.query.order_asc("name");
        self
    }

    pub fn order_by_name_desc(mut self) -> Self {
        self.query = self.query.order_desc("name");
        self
    }

    pub fn order_by_name_asc_using_gbk(mut self) -> Self {
        self.query = self.query.order_gbk_asc("name");
        self
    }

    pub fn order_by_name_desc_using_gbk(mut self) -> Self {
        self.query = self.query.order_gbk_desc("name");
        self
    }


    pub fn select_description(mut self) -> Self {
        self.query = self.query.project("description");
        self
    }

    pub fn project_description(self) -> Self {
        self.select_description()
    }

    pub fn select_description_raw(self, raw_sql_segment: impl Into<String>) -> Self {
        self.select_description_unsafe_raw(UnsafeRawSqlSegment::trusted(raw_sql_segment))
    }

    pub fn select_description_unsafe_raw(mut self, raw_sql_segment: UnsafeRawSqlSegment) -> Self {
        self.query_options
            .raw_projections
            .push(RawProjection::new("description", raw_sql_segment));
        self
    }

    pub fn group_by_description(self) -> Self {
        self.group_by("description")
    }

    pub fn group_by_description_as(self, alias: impl Into<String>) -> Self {
        let alias = alias.into();
        let mut request = self.group_by("description");
        request.query = request
            .query
            .project_expr(alias, Expr::column("description"));
        request
    }

    pub fn group_by_description_with_function(
        self,
        alias: impl Into<String>,
        function: AggregateFunction,
    ) -> Self {
        self.group_by("description")
            .aggregate_with_function("description", alias, function)
    }

    pub fn count_description(self) -> Self {
        self.count_description_as("description_count")
    }

    pub fn count_description_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_count_field("description", alias)
    }

    pub fn sum_description(self) -> Self {
        self.sum_description_as("sum_description")
    }

    pub fn sum_description_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_sum("description", alias)
    }

    pub fn avg_description(self) -> Self {
        self.avg_description_as("avg_description")
    }

    pub fn avg_description_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_avg("description", alias)
    }

    pub fn min_description(self) -> Self {
        self.min_description_as("min_description")
    }

    pub fn min_description_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_min("description", alias)
    }

    pub fn max_description(self) -> Self {
        self.max_description_as("max_description")
    }

    pub fn max_description_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_max("description", alias)
    }

    pub fn unselect_description(mut self) -> Self {
        self.query.projection.retain(|field| field != "description");
        self.query_options.raw_projections.retain(|projection| projection.property_name != "description");
        self
    }


    pub fn with_description(
        mut self,
        operator: FieldOperator,
        values: impl IntoIterator<Item = impl Into<teaql_core::Value>>,
    ) -> Self {
        self.query = self.query.and_filter(field_operator_expr(
            "description",
            operator,
            values.into_iter().map(Into::into).collect(),
        ));
        self
    }

    pub fn create_description_criteria(
        operator: FieldOperator,
        values: impl IntoIterator<Item = impl Into<teaql_core::Value>>,
    ) -> Expr {
        field_operator_expr(
            "description",
            operator,
            values.into_iter().map(Into::into).collect(),
        )
    }

    pub fn with_description_is(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::eq("description", value));
        self
    }



    pub fn with_description_is_not(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::ne("description", value));
        self
    }

    pub fn with_description_greater_than(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::gt("description", value));
        self
    }

    pub fn with_description_greater_than_or_equal_to(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::gte("description", value));
        self
    }

    pub fn with_description_less_than(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::lt("description", value));
        self
    }

    pub fn with_description_less_than_or_equal_to(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::lte("description", value));
        self
    }

    pub fn with_description_between(
        mut self,
        lower: impl Into<teaql_core::Value>,
        upper: impl Into<teaql_core::Value>,
    ) -> Self {
        self.query = self.query.and_filter(Expr::between("description", lower, upper));
        self
    }

    pub fn with_description_between_range<T>(mut self, range: DateRange<T>) -> Self
    where
        T: Into<teaql_core::Value>,
    {
        self.query = self.query.and_filter(Expr::between(
            "description",
            range.start,
            range.end,
        ));
        self
    }

    pub fn with_description_in(
        mut self,
        values: impl IntoIterator<Item = impl Into<teaql_core::Value>>,
    ) -> Self {
        self.query = self.query.and_filter(Expr::in_list(
            "description",
            values.into_iter().map(Into::into),
        ));
        self
    }

    pub fn with_description_not_in(
        mut self,
        values: impl IntoIterator<Item = impl Into<teaql_core::Value>>,
    ) -> Self {
        self.query = self.query.and_filter(Expr::not_in_list(
            "description",
            values.into_iter().map(Into::into),
        ));
        self
    }

    pub fn with_description_containing(mut self, value: impl Into<String>) -> Self {
        self.query = self.query.and_filter(Expr::contain("description", value));
        self
    }

    pub fn with_description_not_containing(mut self, value: impl Into<String>) -> Self {
        self.query = self.query.and_filter(Expr::not_contain("description", value));
        self
    }

    pub fn with_description_starting_with(mut self, value: impl Into<String>) -> Self {
        self.query = self.query.and_filter(Expr::begin_with("description", value));
        self
    }

    pub fn with_description_not_starting_with(mut self, value: impl Into<String>) -> Self {
        self.query = self.query.and_filter(Expr::not_begin_with("description", value));
        self
    }

    pub fn with_description_ending_with(mut self, value: impl Into<String>) -> Self {
        self.query = self.query.and_filter(Expr::end_with("description", value));
        self
    }

    pub fn with_description_not_ending_with(mut self, value: impl Into<String>) -> Self {
        self.query = self.query.and_filter(Expr::not_end_with("description", value));
        self
    }

    pub fn with_description_sounding_like(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::sound_like("description", value));
        self
    }
    pub fn with_description_before(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::lt("description", value));
        self
    }

    pub fn with_description_after(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::gt("description", value));
        self
    }

    pub fn with_description_is_unknown(mut self) -> Self {
        self.query = self.query.and_filter(Expr::is_null("description"));
        self
    }



    pub fn with_description_is_known(mut self) -> Self {
        self.query = self.query.and_filter(Expr::is_not_null("description"));
        self
    }


    pub fn order_by_description_asc(mut self) -> Self {
        self.query = self.query.order_asc("description");
        self
    }

    pub fn order_by_description_desc(mut self) -> Self {
        self.query = self.query.order_desc("description");
        self
    }

    pub fn order_by_description_asc_using_gbk(mut self) -> Self {
        self.query = self.query.order_gbk_asc("description");
        self
    }

    pub fn order_by_description_desc_using_gbk(mut self) -> Self {
        self.query = self.query.order_gbk_desc("description");
        self
    }


    pub fn select_base_price(mut self) -> Self {
        self.query = self.query.project("base_price");
        self
    }

    pub fn project_base_price(self) -> Self {
        self.select_base_price()
    }

    pub fn select_base_price_raw(self, raw_sql_segment: impl Into<String>) -> Self {
        self.select_base_price_unsafe_raw(UnsafeRawSqlSegment::trusted(raw_sql_segment))
    }

    pub fn select_base_price_unsafe_raw(mut self, raw_sql_segment: UnsafeRawSqlSegment) -> Self {
        self.query_options
            .raw_projections
            .push(RawProjection::new("base_price", raw_sql_segment));
        self
    }

    pub fn select_base_price_with_function(self, function: AggregateFunction) -> Self {
        self.select_base_price_as_with_function("base_price", function)
    }

    pub fn select_base_price_as_with_function(
        self,
        alias: impl Into<String>,
        function: AggregateFunction,
    ) -> Self {
        self.aggregate_with_function("base_price", alias, function)
    }

    pub fn group_by_base_price(self) -> Self {
        self.group_by("base_price")
    }

    pub fn group_by_base_price_as(self, alias: impl Into<String>) -> Self {
        let alias = alias.into();
        let mut request = self.group_by("base_price");
        request.query = request
            .query
            .project_expr(alias, Expr::column("base_price"));
        request
    }

    pub fn group_by_base_price_with_function(
        self,
        alias: impl Into<String>,
        function: AggregateFunction,
    ) -> Self {
        self.group_by("base_price")
            .aggregate_with_function("base_price", alias, function)
    }

    pub fn count_base_price(self) -> Self {
        self.count_base_price_as("base_price_count")
    }

    pub fn count_base_price_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_count_field("base_price", alias)
    }

    pub fn sum_base_price(self) -> Self {
        self.sum_base_price_as("sum_base_price")
    }

    pub fn sum_base_price_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_sum("base_price", alias)
    }

    pub fn avg_base_price(self) -> Self {
        self.avg_base_price_as("avg_base_price")
    }

    pub fn avg_base_price_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_avg("base_price", alias)
    }

    pub fn min_base_price(self) -> Self {
        self.min_base_price_as("min_base_price")
    }

    pub fn min_base_price_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_min("base_price", alias)
    }

    pub fn max_base_price(self) -> Self {
        self.max_base_price_as("max_base_price")
    }

    pub fn max_base_price_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_max("base_price", alias)
    }

    pub fn standard_deviation_base_price(self) -> Self {
        self.standard_deviation_base_price_as("stdDev_base_price")
    }

    pub fn standard_deviation_base_price_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_stddev("base_price", alias)
    }

    pub fn square_root_of_population_standard_deviation_base_price(self) -> Self {
        self.square_root_of_population_standard_deviation_base_price_as("stdDevPop_base_price")
    }

    pub fn square_root_of_population_standard_deviation_base_price_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_stddev_pop("base_price", alias)
    }

    pub fn sample_variance_base_price(self) -> Self {
        self.sample_variance_base_price_as("varSamp_base_price")
    }

    pub fn sample_variance_base_price_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_var_samp("base_price", alias)
    }

    pub fn sample_population_variance_base_price(self) -> Self {
        self.sample_population_variance_base_price_as("varPop_base_price")
    }

    pub fn sample_population_variance_base_price_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_var_pop("base_price", alias)
    }

    pub fn unselect_base_price(mut self) -> Self {
        self.query.projection.retain(|field| field != "base_price");
        self.query_options.raw_projections.retain(|projection| projection.property_name != "base_price");
        self
    }


    pub fn with_base_price(
        mut self,
        operator: FieldOperator,
        values: impl IntoIterator<Item = impl Into<teaql_core::Value>>,
    ) -> Self {
        self.query = self.query.and_filter(field_operator_expr(
            "base_price",
            operator,
            values.into_iter().map(Into::into).collect(),
        ));
        self
    }

    pub fn create_base_price_criteria(
        operator: FieldOperator,
        values: impl IntoIterator<Item = impl Into<teaql_core::Value>>,
    ) -> Expr {
        field_operator_expr(
            "base_price",
            operator,
            values.into_iter().map(Into::into).collect(),
        )
    }

    pub fn with_base_price_is(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::eq("base_price", value));
        self
    }



    pub fn with_base_price_is_not(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::ne("base_price", value));
        self
    }

    pub fn with_base_price_greater_than(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::gt("base_price", value));
        self
    }

    pub fn with_base_price_greater_than_or_equal_to(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::gte("base_price", value));
        self
    }

    pub fn with_base_price_less_than(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::lt("base_price", value));
        self
    }

    pub fn with_base_price_less_than_or_equal_to(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::lte("base_price", value));
        self
    }

    pub fn with_base_price_between(
        mut self,
        lower: impl Into<teaql_core::Value>,
        upper: impl Into<teaql_core::Value>,
    ) -> Self {
        self.query = self.query.and_filter(Expr::between("base_price", lower, upper));
        self
    }

    pub fn with_base_price_between_range<T>(mut self, range: DateRange<T>) -> Self
    where
        T: Into<teaql_core::Value>,
    {
        self.query = self.query.and_filter(Expr::between(
            "base_price",
            range.start,
            range.end,
        ));
        self
    }

    pub fn with_base_price_in(
        mut self,
        values: impl IntoIterator<Item = impl Into<teaql_core::Value>>,
    ) -> Self {
        self.query = self.query.and_filter(Expr::in_list(
            "base_price",
            values.into_iter().map(Into::into),
        ));
        self
    }

    pub fn with_base_price_not_in(
        mut self,
        values: impl IntoIterator<Item = impl Into<teaql_core::Value>>,
    ) -> Self {
        self.query = self.query.and_filter(Expr::not_in_list(
            "base_price",
            values.into_iter().map(Into::into),
        ));
        self
    }

    pub fn with_base_price_before(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::lt("base_price", value));
        self
    }

    pub fn with_base_price_after(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::gt("base_price", value));
        self
    }

    pub fn with_base_price_is_unknown(mut self) -> Self {
        self.query = self.query.and_filter(Expr::is_null("base_price"));
        self
    }



    pub fn with_base_price_is_known(mut self) -> Self {
        self.query = self.query.and_filter(Expr::is_not_null("base_price"));
        self
    }


    pub fn order_by_base_price_asc(mut self) -> Self {
        self.query = self.query.order_asc("base_price");
        self
    }

    pub fn order_by_base_price_desc(mut self) -> Self {
        self.query = self.query.order_desc("base_price");
        self
    }

    pub fn order_by_base_price_asc_using_gbk(mut self) -> Self {
        self.query = self.query.order_gbk_asc("base_price");
        self
    }

    pub fn order_by_base_price_desc_using_gbk(mut self) -> Self {
        self.query = self.query.order_gbk_desc("base_price");
        self
    }


    pub fn select_price_per_hour(mut self) -> Self {
        self.query = self.query.project("price_per_hour");
        self
    }

    pub fn project_price_per_hour(self) -> Self {
        self.select_price_per_hour()
    }

    pub fn select_price_per_hour_raw(self, raw_sql_segment: impl Into<String>) -> Self {
        self.select_price_per_hour_unsafe_raw(UnsafeRawSqlSegment::trusted(raw_sql_segment))
    }

    pub fn select_price_per_hour_unsafe_raw(mut self, raw_sql_segment: UnsafeRawSqlSegment) -> Self {
        self.query_options
            .raw_projections
            .push(RawProjection::new("price_per_hour", raw_sql_segment));
        self
    }

    pub fn select_price_per_hour_with_function(self, function: AggregateFunction) -> Self {
        self.select_price_per_hour_as_with_function("price_per_hour", function)
    }

    pub fn select_price_per_hour_as_with_function(
        self,
        alias: impl Into<String>,
        function: AggregateFunction,
    ) -> Self {
        self.aggregate_with_function("price_per_hour", alias, function)
    }

    pub fn group_by_price_per_hour(self) -> Self {
        self.group_by("price_per_hour")
    }

    pub fn group_by_price_per_hour_as(self, alias: impl Into<String>) -> Self {
        let alias = alias.into();
        let mut request = self.group_by("price_per_hour");
        request.query = request
            .query
            .project_expr(alias, Expr::column("price_per_hour"));
        request
    }

    pub fn group_by_price_per_hour_with_function(
        self,
        alias: impl Into<String>,
        function: AggregateFunction,
    ) -> Self {
        self.group_by("price_per_hour")
            .aggregate_with_function("price_per_hour", alias, function)
    }

    pub fn count_price_per_hour(self) -> Self {
        self.count_price_per_hour_as("price_per_hour_count")
    }

    pub fn count_price_per_hour_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_count_field("price_per_hour", alias)
    }

    pub fn sum_price_per_hour(self) -> Self {
        self.sum_price_per_hour_as("sum_price_per_hour")
    }

    pub fn sum_price_per_hour_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_sum("price_per_hour", alias)
    }

    pub fn avg_price_per_hour(self) -> Self {
        self.avg_price_per_hour_as("avg_price_per_hour")
    }

    pub fn avg_price_per_hour_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_avg("price_per_hour", alias)
    }

    pub fn min_price_per_hour(self) -> Self {
        self.min_price_per_hour_as("min_price_per_hour")
    }

    pub fn min_price_per_hour_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_min("price_per_hour", alias)
    }

    pub fn max_price_per_hour(self) -> Self {
        self.max_price_per_hour_as("max_price_per_hour")
    }

    pub fn max_price_per_hour_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_max("price_per_hour", alias)
    }

    pub fn standard_deviation_price_per_hour(self) -> Self {
        self.standard_deviation_price_per_hour_as("stdDev_price_per_hour")
    }

    pub fn standard_deviation_price_per_hour_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_stddev("price_per_hour", alias)
    }

    pub fn square_root_of_population_standard_deviation_price_per_hour(self) -> Self {
        self.square_root_of_population_standard_deviation_price_per_hour_as("stdDevPop_price_per_hour")
    }

    pub fn square_root_of_population_standard_deviation_price_per_hour_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_stddev_pop("price_per_hour", alias)
    }

    pub fn sample_variance_price_per_hour(self) -> Self {
        self.sample_variance_price_per_hour_as("varSamp_price_per_hour")
    }

    pub fn sample_variance_price_per_hour_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_var_samp("price_per_hour", alias)
    }

    pub fn sample_population_variance_price_per_hour(self) -> Self {
        self.sample_population_variance_price_per_hour_as("varPop_price_per_hour")
    }

    pub fn sample_population_variance_price_per_hour_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_var_pop("price_per_hour", alias)
    }

    pub fn unselect_price_per_hour(mut self) -> Self {
        self.query.projection.retain(|field| field != "price_per_hour");
        self.query_options.raw_projections.retain(|projection| projection.property_name != "price_per_hour");
        self
    }


    pub fn with_price_per_hour(
        mut self,
        operator: FieldOperator,
        values: impl IntoIterator<Item = impl Into<teaql_core::Value>>,
    ) -> Self {
        self.query = self.query.and_filter(field_operator_expr(
            "price_per_hour",
            operator,
            values.into_iter().map(Into::into).collect(),
        ));
        self
    }

    pub fn create_price_per_hour_criteria(
        operator: FieldOperator,
        values: impl IntoIterator<Item = impl Into<teaql_core::Value>>,
    ) -> Expr {
        field_operator_expr(
            "price_per_hour",
            operator,
            values.into_iter().map(Into::into).collect(),
        )
    }

    pub fn with_price_per_hour_is(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::eq("price_per_hour", value));
        self
    }



    pub fn with_price_per_hour_is_not(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::ne("price_per_hour", value));
        self
    }

    pub fn with_price_per_hour_greater_than(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::gt("price_per_hour", value));
        self
    }

    pub fn with_price_per_hour_greater_than_or_equal_to(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::gte("price_per_hour", value));
        self
    }

    pub fn with_price_per_hour_less_than(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::lt("price_per_hour", value));
        self
    }

    pub fn with_price_per_hour_less_than_or_equal_to(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::lte("price_per_hour", value));
        self
    }

    pub fn with_price_per_hour_between(
        mut self,
        lower: impl Into<teaql_core::Value>,
        upper: impl Into<teaql_core::Value>,
    ) -> Self {
        self.query = self.query.and_filter(Expr::between("price_per_hour", lower, upper));
        self
    }

    pub fn with_price_per_hour_between_range<T>(mut self, range: DateRange<T>) -> Self
    where
        T: Into<teaql_core::Value>,
    {
        self.query = self.query.and_filter(Expr::between(
            "price_per_hour",
            range.start,
            range.end,
        ));
        self
    }

    pub fn with_price_per_hour_in(
        mut self,
        values: impl IntoIterator<Item = impl Into<teaql_core::Value>>,
    ) -> Self {
        self.query = self.query.and_filter(Expr::in_list(
            "price_per_hour",
            values.into_iter().map(Into::into),
        ));
        self
    }

    pub fn with_price_per_hour_not_in(
        mut self,
        values: impl IntoIterator<Item = impl Into<teaql_core::Value>>,
    ) -> Self {
        self.query = self.query.and_filter(Expr::not_in_list(
            "price_per_hour",
            values.into_iter().map(Into::into),
        ));
        self
    }

    pub fn with_price_per_hour_before(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::lt("price_per_hour", value));
        self
    }

    pub fn with_price_per_hour_after(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::gt("price_per_hour", value));
        self
    }

    pub fn with_price_per_hour_is_unknown(mut self) -> Self {
        self.query = self.query.and_filter(Expr::is_null("price_per_hour"));
        self
    }



    pub fn with_price_per_hour_is_known(mut self) -> Self {
        self.query = self.query.and_filter(Expr::is_not_null("price_per_hour"));
        self
    }


    pub fn order_by_price_per_hour_asc(mut self) -> Self {
        self.query = self.query.order_asc("price_per_hour");
        self
    }

    pub fn order_by_price_per_hour_desc(mut self) -> Self {
        self.query = self.query.order_desc("price_per_hour");
        self
    }

    pub fn order_by_price_per_hour_asc_using_gbk(mut self) -> Self {
        self.query = self.query.order_gbk_asc("price_per_hour");
        self
    }

    pub fn order_by_price_per_hour_desc_using_gbk(mut self) -> Self {
        self.query = self.query.order_gbk_desc("price_per_hour");
        self
    }


    pub fn select_is_active(mut self) -> Self {
        self.query = self.query.project("is_active");
        self
    }

    pub fn project_is_active(self) -> Self {
        self.select_is_active()
    }

    pub fn select_is_active_raw(self, raw_sql_segment: impl Into<String>) -> Self {
        self.select_is_active_unsafe_raw(UnsafeRawSqlSegment::trusted(raw_sql_segment))
    }

    pub fn select_is_active_unsafe_raw(mut self, raw_sql_segment: UnsafeRawSqlSegment) -> Self {
        self.query_options
            .raw_projections
            .push(RawProjection::new("is_active", raw_sql_segment));
        self
    }

    pub fn group_by_is_active(self) -> Self {
        self.group_by("is_active")
    }

    pub fn group_by_is_active_as(self, alias: impl Into<String>) -> Self {
        let alias = alias.into();
        let mut request = self.group_by("is_active");
        request.query = request
            .query
            .project_expr(alias, Expr::column("is_active"));
        request
    }

    pub fn group_by_is_active_with_function(
        self,
        alias: impl Into<String>,
        function: AggregateFunction,
    ) -> Self {
        self.group_by("is_active")
            .aggregate_with_function("is_active", alias, function)
    }

    pub fn count_is_active(self) -> Self {
        self.count_is_active_as("is_active_count")
    }

    pub fn count_is_active_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_count_field("is_active", alias)
    }

    pub fn sum_is_active(self) -> Self {
        self.sum_is_active_as("sum_is_active")
    }

    pub fn sum_is_active_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_sum("is_active", alias)
    }

    pub fn avg_is_active(self) -> Self {
        self.avg_is_active_as("avg_is_active")
    }

    pub fn avg_is_active_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_avg("is_active", alias)
    }

    pub fn min_is_active(self) -> Self {
        self.min_is_active_as("min_is_active")
    }

    pub fn min_is_active_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_min("is_active", alias)
    }

    pub fn max_is_active(self) -> Self {
        self.max_is_active_as("max_is_active")
    }

    pub fn max_is_active_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_max("is_active", alias)
    }

    pub fn unselect_is_active(mut self) -> Self {
        self.query.projection.retain(|field| field != "is_active");
        self.query_options.raw_projections.retain(|projection| projection.property_name != "is_active");
        self
    }


    pub fn with_is_active(
        mut self,
        operator: FieldOperator,
        values: impl IntoIterator<Item = impl Into<teaql_core::Value>>,
    ) -> Self {
        self.query = self.query.and_filter(field_operator_expr(
            "is_active",
            operator,
            values.into_iter().map(Into::into).collect(),
        ));
        self
    }

    pub fn create_is_active_criteria(
        operator: FieldOperator,
        values: impl IntoIterator<Item = impl Into<teaql_core::Value>>,
    ) -> Expr {
        field_operator_expr(
            "is_active",
            operator,
            values.into_iter().map(Into::into).collect(),
        )
    }

    pub fn with_is_active_is(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::eq("is_active", value));
        self
    }



    pub fn with_is_active_is_not(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::ne("is_active", value));
        self
    }

    pub fn with_is_active_greater_than(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::gt("is_active", value));
        self
    }

    pub fn with_is_active_greater_than_or_equal_to(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::gte("is_active", value));
        self
    }

    pub fn with_is_active_less_than(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::lt("is_active", value));
        self
    }

    pub fn with_is_active_less_than_or_equal_to(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::lte("is_active", value));
        self
    }

    pub fn with_is_active_between(
        mut self,
        lower: impl Into<teaql_core::Value>,
        upper: impl Into<teaql_core::Value>,
    ) -> Self {
        self.query = self.query.and_filter(Expr::between("is_active", lower, upper));
        self
    }

    pub fn with_is_active_between_range<T>(mut self, range: DateRange<T>) -> Self
    where
        T: Into<teaql_core::Value>,
    {
        self.query = self.query.and_filter(Expr::between(
            "is_active",
            range.start,
            range.end,
        ));
        self
    }

    pub fn with_is_active_in(
        mut self,
        values: impl IntoIterator<Item = impl Into<teaql_core::Value>>,
    ) -> Self {
        self.query = self.query.and_filter(Expr::in_list(
            "is_active",
            values.into_iter().map(Into::into),
        ));
        self
    }

    pub fn with_is_active_not_in(
        mut self,
        values: impl IntoIterator<Item = impl Into<teaql_core::Value>>,
    ) -> Self {
        self.query = self.query.and_filter(Expr::not_in_list(
            "is_active",
            values.into_iter().map(Into::into),
        ));
        self
    }

    pub fn with_is_active_before(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::lt("is_active", value));
        self
    }

    pub fn with_is_active_after(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::gt("is_active", value));
        self
    }

    pub fn with_is_active_is_unknown(mut self) -> Self {
        self.query = self.query.and_filter(Expr::is_null("is_active"));
        self
    }



    pub fn with_is_active_is_known(mut self) -> Self {
        self.query = self.query.and_filter(Expr::is_not_null("is_active"));
        self
    }


    pub fn order_by_is_active_asc(mut self) -> Self {
        self.query = self.query.order_asc("is_active");
        self
    }

    pub fn order_by_is_active_desc(mut self) -> Self {
        self.query = self.query.order_desc("is_active");
        self
    }

    pub fn order_by_is_active_asc_using_gbk(mut self) -> Self {
        self.query = self.query.order_gbk_asc("is_active");
        self
    }

    pub fn order_by_is_active_desc_using_gbk(mut self) -> Self {
        self.query = self.query.order_gbk_desc("is_active");
        self
    }


    pub fn select_create_time(mut self) -> Self {
        self.query = self.query.project("create_time");
        self
    }

    pub fn project_create_time(self) -> Self {
        self.select_create_time()
    }

    pub fn select_create_time_raw(self, raw_sql_segment: impl Into<String>) -> Self {
        self.select_create_time_unsafe_raw(UnsafeRawSqlSegment::trusted(raw_sql_segment))
    }

    pub fn select_create_time_unsafe_raw(mut self, raw_sql_segment: UnsafeRawSqlSegment) -> Self {
        self.query_options
            .raw_projections
            .push(RawProjection::new("create_time", raw_sql_segment));
        self
    }

    pub fn group_by_create_time(self) -> Self {
        self.group_by("create_time")
    }

    pub fn group_by_create_time_as(self, alias: impl Into<String>) -> Self {
        let alias = alias.into();
        let mut request = self.group_by("create_time");
        request.query = request
            .query
            .project_expr(alias, Expr::column("create_time"));
        request
    }

    pub fn group_by_create_time_with_function(
        self,
        alias: impl Into<String>,
        function: AggregateFunction,
    ) -> Self {
        self.group_by("create_time")
            .aggregate_with_function("create_time", alias, function)
    }

    pub fn count_create_time(self) -> Self {
        self.count_create_time_as("create_time_count")
    }

    pub fn count_create_time_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_count_field("create_time", alias)
    }

    pub fn sum_create_time(self) -> Self {
        self.sum_create_time_as("sum_create_time")
    }

    pub fn sum_create_time_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_sum("create_time", alias)
    }

    pub fn avg_create_time(self) -> Self {
        self.avg_create_time_as("avg_create_time")
    }

    pub fn avg_create_time_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_avg("create_time", alias)
    }

    pub fn min_create_time(self) -> Self {
        self.min_create_time_as("min_create_time")
    }

    pub fn min_create_time_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_min("create_time", alias)
    }

    pub fn max_create_time(self) -> Self {
        self.max_create_time_as("max_create_time")
    }

    pub fn max_create_time_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_max("create_time", alias)
    }

    pub fn unselect_create_time(mut self) -> Self {
        self.query.projection.retain(|field| field != "create_time");
        self.query_options.raw_projections.retain(|projection| projection.property_name != "create_time");
        self
    }


    pub fn with_create_time(
        mut self,
        operator: FieldOperator,
        values: impl IntoIterator<Item = impl Into<teaql_core::Value>>,
    ) -> Self {
        self.query = self.query.and_filter(field_operator_expr(
            "create_time",
            operator,
            values.into_iter().map(Into::into).collect(),
        ));
        self
    }

    pub fn create_create_time_criteria(
        operator: FieldOperator,
        values: impl IntoIterator<Item = impl Into<teaql_core::Value>>,
    ) -> Expr {
        field_operator_expr(
            "create_time",
            operator,
            values.into_iter().map(Into::into).collect(),
        )
    }

    pub fn with_create_time_is(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::eq("create_time", value));
        self
    }



    pub fn with_create_time_is_not(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::ne("create_time", value));
        self
    }

    pub fn with_create_time_greater_than(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::gt("create_time", value));
        self
    }

    pub fn with_create_time_greater_than_or_equal_to(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::gte("create_time", value));
        self
    }

    pub fn with_create_time_less_than(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::lt("create_time", value));
        self
    }

    pub fn with_create_time_less_than_or_equal_to(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::lte("create_time", value));
        self
    }

    pub fn with_create_time_between(
        mut self,
        lower: impl Into<teaql_core::Value>,
        upper: impl Into<teaql_core::Value>,
    ) -> Self {
        self.query = self.query.and_filter(Expr::between("create_time", lower, upper));
        self
    }

    pub fn with_create_time_between_range<T>(mut self, range: DateRange<T>) -> Self
    where
        T: Into<teaql_core::Value>,
    {
        self.query = self.query.and_filter(Expr::between(
            "create_time",
            range.start,
            range.end,
        ));
        self
    }

    pub fn with_create_time_in(
        mut self,
        values: impl IntoIterator<Item = impl Into<teaql_core::Value>>,
    ) -> Self {
        self.query = self.query.and_filter(Expr::in_list(
            "create_time",
            values.into_iter().map(Into::into),
        ));
        self
    }

    pub fn with_create_time_not_in(
        mut self,
        values: impl IntoIterator<Item = impl Into<teaql_core::Value>>,
    ) -> Self {
        self.query = self.query.and_filter(Expr::not_in_list(
            "create_time",
            values.into_iter().map(Into::into),
        ));
        self
    }

    pub fn with_create_time_before(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::lt("create_time", value));
        self
    }

    pub fn with_create_time_after(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::gt("create_time", value));
        self
    }

    pub fn with_create_time_is_unknown(mut self) -> Self {
        self.query = self.query.and_filter(Expr::is_null("create_time"));
        self
    }



    pub fn with_create_time_is_known(mut self) -> Self {
        self.query = self.query.and_filter(Expr::is_not_null("create_time"));
        self
    }


    pub fn order_by_create_time_asc(mut self) -> Self {
        self.query = self.query.order_asc("create_time");
        self
    }

    pub fn order_by_create_time_desc(mut self) -> Self {
        self.query = self.query.order_desc("create_time");
        self
    }

    pub fn order_by_create_time_asc_using_gbk(mut self) -> Self {
        self.query = self.query.order_gbk_asc("create_time");
        self
    }

    pub fn order_by_create_time_desc_using_gbk(mut self) -> Self {
        self.query = self.query.order_gbk_desc("create_time");
        self
    }


    pub fn select_update_time(mut self) -> Self {
        self.query = self.query.project("update_time");
        self
    }

    pub fn project_update_time(self) -> Self {
        self.select_update_time()
    }

    pub fn select_update_time_raw(self, raw_sql_segment: impl Into<String>) -> Self {
        self.select_update_time_unsafe_raw(UnsafeRawSqlSegment::trusted(raw_sql_segment))
    }

    pub fn select_update_time_unsafe_raw(mut self, raw_sql_segment: UnsafeRawSqlSegment) -> Self {
        self.query_options
            .raw_projections
            .push(RawProjection::new("update_time", raw_sql_segment));
        self
    }

    pub fn group_by_update_time(self) -> Self {
        self.group_by("update_time")
    }

    pub fn group_by_update_time_as(self, alias: impl Into<String>) -> Self {
        let alias = alias.into();
        let mut request = self.group_by("update_time");
        request.query = request
            .query
            .project_expr(alias, Expr::column("update_time"));
        request
    }

    pub fn group_by_update_time_with_function(
        self,
        alias: impl Into<String>,
        function: AggregateFunction,
    ) -> Self {
        self.group_by("update_time")
            .aggregate_with_function("update_time", alias, function)
    }

    pub fn count_update_time(self) -> Self {
        self.count_update_time_as("update_time_count")
    }

    pub fn count_update_time_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_count_field("update_time", alias)
    }

    pub fn sum_update_time(self) -> Self {
        self.sum_update_time_as("sum_update_time")
    }

    pub fn sum_update_time_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_sum("update_time", alias)
    }

    pub fn avg_update_time(self) -> Self {
        self.avg_update_time_as("avg_update_time")
    }

    pub fn avg_update_time_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_avg("update_time", alias)
    }

    pub fn min_update_time(self) -> Self {
        self.min_update_time_as("min_update_time")
    }

    pub fn min_update_time_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_min("update_time", alias)
    }

    pub fn max_update_time(self) -> Self {
        self.max_update_time_as("max_update_time")
    }

    pub fn max_update_time_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_max("update_time", alias)
    }

    pub fn unselect_update_time(mut self) -> Self {
        self.query.projection.retain(|field| field != "update_time");
        self.query_options.raw_projections.retain(|projection| projection.property_name != "update_time");
        self
    }


    pub fn with_update_time(
        mut self,
        operator: FieldOperator,
        values: impl IntoIterator<Item = impl Into<teaql_core::Value>>,
    ) -> Self {
        self.query = self.query.and_filter(field_operator_expr(
            "update_time",
            operator,
            values.into_iter().map(Into::into).collect(),
        ));
        self
    }

    pub fn create_update_time_criteria(
        operator: FieldOperator,
        values: impl IntoIterator<Item = impl Into<teaql_core::Value>>,
    ) -> Expr {
        field_operator_expr(
            "update_time",
            operator,
            values.into_iter().map(Into::into).collect(),
        )
    }

    pub fn with_update_time_is(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::eq("update_time", value));
        self
    }



    pub fn with_update_time_is_not(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::ne("update_time", value));
        self
    }

    pub fn with_update_time_greater_than(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::gt("update_time", value));
        self
    }

    pub fn with_update_time_greater_than_or_equal_to(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::gte("update_time", value));
        self
    }

    pub fn with_update_time_less_than(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::lt("update_time", value));
        self
    }

    pub fn with_update_time_less_than_or_equal_to(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::lte("update_time", value));
        self
    }

    pub fn with_update_time_between(
        mut self,
        lower: impl Into<teaql_core::Value>,
        upper: impl Into<teaql_core::Value>,
    ) -> Self {
        self.query = self.query.and_filter(Expr::between("update_time", lower, upper));
        self
    }

    pub fn with_update_time_between_range<T>(mut self, range: DateRange<T>) -> Self
    where
        T: Into<teaql_core::Value>,
    {
        self.query = self.query.and_filter(Expr::between(
            "update_time",
            range.start,
            range.end,
        ));
        self
    }

    pub fn with_update_time_in(
        mut self,
        values: impl IntoIterator<Item = impl Into<teaql_core::Value>>,
    ) -> Self {
        self.query = self.query.and_filter(Expr::in_list(
            "update_time",
            values.into_iter().map(Into::into),
        ));
        self
    }

    pub fn with_update_time_not_in(
        mut self,
        values: impl IntoIterator<Item = impl Into<teaql_core::Value>>,
    ) -> Self {
        self.query = self.query.and_filter(Expr::not_in_list(
            "update_time",
            values.into_iter().map(Into::into),
        ));
        self
    }

    pub fn with_update_time_before(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::lt("update_time", value));
        self
    }

    pub fn with_update_time_after(mut self, value: impl Into<teaql_core::Value>) -> Self {
        self.query = self.query.and_filter(Expr::gt("update_time", value));
        self
    }

    pub fn with_update_time_is_unknown(mut self) -> Self {
        self.query = self.query.and_filter(Expr::is_null("update_time"));
        self
    }



    pub fn with_update_time_is_known(mut self) -> Self {
        self.query = self.query.and_filter(Expr::is_not_null("update_time"));
        self
    }


    pub fn order_by_update_time_asc(mut self) -> Self {
        self.query = self.query.order_asc("update_time");
        self
    }

    pub fn order_by_update_time_desc(mut self) -> Self {
        self.query = self.query.order_desc("update_time");
        self
    }

    pub fn order_by_update_time_asc_using_gbk(mut self) -> Self {
        self.query = self.query.order_gbk_asc("update_time");
        self
    }

    pub fn order_by_update_time_desc_using_gbk(mut self) -> Self {
        self.query = self.query.order_gbk_desc("update_time");
        self
    }

    pub fn group_by_version(self) -> Self {
        self.group_by("version")
    }

    pub fn group_by_version_as(self, alias: impl Into<String>) -> Self {
        let alias = alias.into();
        let mut request = self.group_by("version");
        request.query = request
            .query
            .project_expr(alias, Expr::column("version"));
        request
    }

    pub fn group_by_version_with_function(
        self,
        alias: impl Into<String>,
        function: AggregateFunction,
    ) -> Self {
        self.group_by("version")
            .aggregate_with_function("version", alias, function)
    }

    pub fn count_version(self) -> Self {
        self.count_version_as("version_count")
    }

    pub fn count_version_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_count_field("version", alias)
    }

    pub fn sum_version(self) -> Self {
        self.sum_version_as("sum_version")
    }

    pub fn sum_version_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_sum("version", alias)
    }

    pub fn avg_version(self) -> Self {
        self.avg_version_as("avg_version")
    }

    pub fn avg_version_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_avg("version", alias)
    }

    pub fn min_version(self) -> Self {
        self.min_version_as("min_version")
    }

    pub fn min_version_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_min("version", alias)
    }

    pub fn max_version(self) -> Self {
        self.max_version_as("max_version")
    }

    pub fn max_version_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_max("version", alias)
    }

    pub fn order_by_version_asc(mut self) -> Self {
        self.query = self.query.order_asc("version");
        self
    }

    pub fn order_by_version_desc(mut self) -> Self {
        self.query = self.query.order_desc("version");
        self
    }

    pub fn order_by_version_asc_using_gbk(mut self) -> Self {
        self.query = self.query.order_gbk_asc("version");
        self
    }

    pub fn order_by_version_desc_using_gbk(mut self) -> Self {
        self.query = self.query.order_gbk_desc("version");
        self
    }
    /// Please use `with_service_category_is` instead
    pub(crate) fn filter_by_service_category(mut self, value: impl EntityReference) -> Self {
        self.query = self.query.and_filter(Expr::eq("service_category_id", value.entity_id_value()));
        self
    }
    /// Complex relation filter for `service_category`.
    ///
    /// **Usage Priority:**
    ///
    /// 1. **Preferred**: If you only want to filter by specific known constants, please **prefer** the generated semantic shortcut methods, such as:
    ///    - [`Self::with_service_category_is_xxx`]
    ///
    ///    This gives the best code readability.
    ///
    /// 2. **Advanced**: Only use this method when you need to perform advanced searches, dynamic subqueries, or filter based on complex relation conditions.
    ///
    /// # Example
    /// ```rust
    /// // Only use when building dynamic queries
    /// let dynamic_query = crate::Q::service_categories_minimal().filter(...);
    /// let request = crate::Q::services().with_service_category_matching(dynamic_query);
    /// ```
    pub fn with_service_category_matching(mut self, request: impl Into<QuerySelection>) -> Self {
        let selection = request.into();
        self.query = self.query.and_filter(Expr::in_subquery(
            "service_category_id",
            <crate::ServiceCategory as teaql_core::TeaqlEntity>::entity_descriptor(),
            selection.query.clone(),
            "id",
        ));
        self.relation_filters.push(RelationFilter::new("service_category", selection));
        self
    }


    /// Complex relation filter for `service_category`.
    ///
    /// **Usage Priority:**
    ///
    /// 1. **Preferred**: If you only want to filter by specific known constants, please **prefer** the generated semantic shortcut methods, such as:
    ///    - [`Self::with_service_category_is_not_xxx`]
    ///
    ///    This gives the best code readability.
    ///
    /// 2. **Advanced**: Only use this method when you need to perform advanced searches, dynamic subqueries, or filter based on complex relation conditions.
    ///
    /// # Example
    /// ```rust
    /// // Only use when building dynamic queries
    /// let dynamic_query = crate::Q::service_categories_minimal().filter(...);
    /// let request = crate::Q::services().without_service_category_matching(dynamic_query);
    /// ```
    pub fn without_service_category_matching(mut self, request: impl Into<QuerySelection>) -> Self {
        let selection = request.into();
        self.query = self.query.and_filter(Expr::not_in_subquery(
            "service_category_id",
            <crate::ServiceCategory as teaql_core::TeaqlEntity>::entity_descriptor(),
            selection.query.clone(),
            "id",
        ));
        self.relation_filters.push(RelationFilter::new("service_category", selection));
        self
    }


    pub fn have_service_category(mut self) -> Self {
        self.query = self.query.and_filter(Expr::is_not_null("service_category_id"));
        self
    }

    pub fn have_no_service_category(mut self) -> Self {
        self.query = self.query.and_filter(Expr::is_null("service_category_id"));
        self
    }


    pub fn group_by_service_category(self) -> Self {
        self.group_by("service_category_id")
    }

    pub fn group_by_service_category_as(self, alias: impl Into<String>) -> Self {
        let alias = alias.into();
        let mut request = self.group_by("service_category_id");
        request.query = request
            .query
            .project_expr(alias, Expr::column("service_category_id"));
        request
    }

    pub fn group_by_service_category_with_function(
        self,
        alias: impl Into<String>,
        function: AggregateFunction,
    ) -> Self {
        self.group_by("service_category_id")
            .aggregate_with_function("service_category_id", alias, function)
    }

    pub fn group_by_service_category_with(mut self, request: impl Into<QuerySelection>) -> Self {
        self.query = self.query.group_by("service_category_id");
        self.query_options.object_group_bys.push(ObjectGroupBy::new(
            "service_category",
            "service_category_id",
            request,
        ));
        self
    }

    pub fn group_by_service_category_with_details(self) -> Self {
        self.group_by_service_category_with_details_from(crate::Q::service_categories().unlimited())
    }

    pub fn group_by_service_category_with_details_from(self, request: impl Into<QuerySelection>) -> Self {
        self.group_by_service_category_with(request)
    }


    pub fn roll_up_to_service_category(self) -> Self {
        self.roll_up_to_service_category_with(crate::Q::service_categories().unlimited())
    }

    pub fn roll_up_to_service_category_with(self, request: impl Into<QuerySelection>) -> Self {
        let selection = request.into();
        self.with_service_category_matching(selection.clone())
            .group_by_service_category_with(selection)
    }

    pub fn count_service_category(self) -> Self {
        self.count_service_category_as("service_category_count")
    }

    pub fn count_service_category_as(self, alias: impl Into<String>) -> Self {
        self.aggregate_count_field("service_category_id", alias)
    }

    pub fn unselect_service_category(mut self) -> Self {
        self.query.projection.retain(|field| field != "service_category_id");
        self.query.relations.retain(|relation| relation.name != "service_category");
        self
    }
    pub fn service_category_is_moving(self) -> Self {
        self.filter_by_service_category(1001_u64)
    }

    pub fn with_service_category_is_moving(self) -> Self {
        self.filter_by_service_category(1001_u64)
    }



    pub fn with_service_category_is_not_moving(mut self) -> Self {
        self.query = self.query.and_filter(Expr::ne("service_category_id", 1001_u64));
        self
    }


    pub fn service_category_is_cleaning(self) -> Self {
        self.filter_by_service_category(1002_u64)
    }

    pub fn with_service_category_is_cleaning(self) -> Self {
        self.filter_by_service_category(1002_u64)
    }



    pub fn with_service_category_is_not_cleaning(mut self) -> Self {
        self.query = self.query.and_filter(Expr::ne("service_category_id", 1002_u64));
        self
    }


    pub fn service_category_is_box_rental(self) -> Self {
        self.filter_by_service_category(1003_u64)
    }

    pub fn with_service_category_is_box_rental(self) -> Self {
        self.filter_by_service_category(1003_u64)
    }



    pub fn with_service_category_is_not_box_rental(mut self) -> Self {
        self.query = self.query.and_filter(Expr::ne("service_category_id", 1003_u64));
        self
    }


    pub fn service_category_is_additional(self) -> Self {
        self.filter_by_service_category(1004_u64)
    }

    pub fn with_service_category_is_additional(self) -> Self {
        self.filter_by_service_category(1004_u64)
    }



    pub fn with_service_category_is_not_additional(mut self) -> Self {
        self.query = self.query.and_filter(Expr::ne("service_category_id", 1004_u64));
        self
    }


    pub fn select_service_category(mut self) -> Self {
        self.query = self.query.relation("service_category");
        self
    }

    pub fn select_service_category_with(mut self, request: impl Into<QuerySelection>) -> Self {
        let selection = request.into();
        self.query = self.query.relation_query("service_category", selection.clone().into_query());
        self.relation_selections.push(RelationSelection::new("service_category", selection));
        self
}

    pub fn facet_by_service_category_as(self, facet_name: impl Into<String>, request: impl Into<QuerySelection>) -> Self {
        self.facet_by_service_category_as_with_options(facet_name, request, true)
    }

    pub fn facet_by_service_category_as_with_options(
        mut self,
        facet_name: impl Into<String>,
        request: impl Into<QuerySelection>,
        include_all_facets: bool,
    ) -> Self {
        self.query_options.facets.push(FacetRequest::new(
            facet_name,
            "service_category",
            request,
            include_all_facets,
        ));
        self
    }
    pub fn have_service_configurations(self) -> Self {
        self.with_service_configuration_list_matching(SelectQuery::new("ServiceConfiguration"))
    }

    pub fn have_no_service_configurations(self) -> Self {
        self.without_service_configuration_list_matching(SelectQuery::new("ServiceConfiguration"))
    }

    pub fn with_service_configuration_list_matching(mut self, request: impl Into<QuerySelection>) -> Self {
        let selection = request.into();
        self.query = self.query.and_filter(Expr::in_subquery(
            "id",
            <crate::ServiceConfiguration as teaql_core::TeaqlEntity>::entity_descriptor(),
            selection.query.clone(),
            "service_id",
        ));
        self.relation_filters.push(RelationFilter::new("service_configuration_list", selection));
        self
    }

    pub fn without_service_configuration_list_matching(mut self, request: impl Into<QuerySelection>) -> Self {
        let selection = request.into();
        self.query = self.query.and_filter(Expr::not_in_subquery(
            "id",
            <crate::ServiceConfiguration as teaql_core::TeaqlEntity>::entity_descriptor(),
            selection.query.clone(),
            "service_id",
        ));
        self.relation_filters.push(RelationFilter::new("service_configuration_list", selection));
        self
    }

    pub fn select_service_configuration_list(mut self) -> Self {
        self.query = self.query.relation("service_configuration_list");
        self
    }

    pub fn select_service_configuration_list_with(mut self, request: impl Into<QuerySelection>) -> Self {
        let selection = request.into();
        self.query = self.query.relation_query("service_configuration_list", selection.clone().into_query());
        self.relation_selections.push(RelationSelection::new("service_configuration_list", selection));
        self
}

    pub fn have_pricing_rules(self) -> Self {
        self.with_pricing_rule_list_matching(SelectQuery::new("PricingRule"))
    }

    pub fn have_no_pricing_rules(self) -> Self {
        self.without_pricing_rule_list_matching(SelectQuery::new("PricingRule"))
    }

    pub fn with_pricing_rule_list_matching(mut self, request: impl Into<QuerySelection>) -> Self {
        let selection = request.into();
        self.query = self.query.and_filter(Expr::in_subquery(
            "id",
            <crate::PricingRule as teaql_core::TeaqlEntity>::entity_descriptor(),
            selection.query.clone(),
            "service_id",
        ));
        self.relation_filters.push(RelationFilter::new("pricing_rule_list", selection));
        self
    }

    pub fn without_pricing_rule_list_matching(mut self, request: impl Into<QuerySelection>) -> Self {
        let selection = request.into();
        self.query = self.query.and_filter(Expr::not_in_subquery(
            "id",
            <crate::PricingRule as teaql_core::TeaqlEntity>::entity_descriptor(),
            selection.query.clone(),
            "service_id",
        ));
        self.relation_filters.push(RelationFilter::new("pricing_rule_list", selection));
        self
    }

    pub fn select_pricing_rule_list(mut self) -> Self {
        self.query = self.query.relation("pricing_rule_list");
        self
    }

    pub fn select_pricing_rule_list_with(mut self, request: impl Into<QuerySelection>) -> Self {
        let selection = request.into();
        self.query = self.query.relation_query("pricing_rule_list", selection.clone().into_query());
        self.relation_selections.push(RelationSelection::new("pricing_rule_list", selection));
        self
}
    pub fn count_service_configurations(self) -> Self {
        self.count_service_configurations_as("count_service_configurations")
    }

    pub fn count_service_configurations_as(self, alias: impl Into<String>) -> Self {
        self.count_service_configurations_with(alias, crate::Q::service_configurations().unlimited())
    }

    pub fn count_service_configurations_with(mut self, alias: impl Into<String>, request: impl Into<QuerySelection>) -> Self {
        let selection = request.into();
        self.query_options.relation_aggregates.push(RelationAggregate::new(
            "service_configuration_list",
            alias,
            selection,
            true,
        ));
        self
    }

    pub fn stats_from_service_configurations(self, request: impl Into<QuerySelection>) -> Self {
        self.stats_from_service_configurations_as("refinements", request)
    }

    pub fn stats_from_service_configurations_as(mut self, alias: impl Into<String>, request: impl Into<QuerySelection>) -> Self {
        let selection = request.into();
        self.query_options.relation_aggregates.push(RelationAggregate::new(
            "service_configuration_list",
            alias,
            selection,
            false,
        ));
        self
    }

    pub fn group_by_service_configurations_with_details(self, request: impl Into<QuerySelection>) -> Self {
        self.stats_from_service_configurations(request)
    }


    pub fn sum_config_value_of_service_configurations(self) -> Self {
        self.sum_config_value_of_service_configurations_as("sum_config_value_of_service_configurations", crate::Q::service_configurations().unlimited())
    }

    pub fn sum_config_value_of_service_configurations_as(self, alias: impl Into<String>, request: impl Into<QuerySelection>) -> Self {
        self.stats_from_service_configurations_as(alias, request.into().into_query().sum("config_value", "sum_config_value"))
    }
    pub fn min_config_value_of_service_configurations(self) -> Self {
        self.min_config_value_of_service_configurations_as("min_config_value_of_service_configurations", crate::Q::service_configurations().unlimited())
    }

    pub fn min_config_value_of_service_configurations_as(self, alias: impl Into<String>, request: impl Into<QuerySelection>) -> Self {
        self.stats_from_service_configurations_as(alias, request.into().into_query().min("config_value", "min_config_value"))
    }
    pub fn max_config_value_of_service_configurations(self) -> Self {
        self.max_config_value_of_service_configurations_as("max_config_value_of_service_configurations", crate::Q::service_configurations().unlimited())
    }

    pub fn max_config_value_of_service_configurations_as(self, alias: impl Into<String>, request: impl Into<QuerySelection>) -> Self {
        self.stats_from_service_configurations_as(alias, request.into().into_query().max("config_value", "max_config_value"))
    }
    pub fn avg_config_value_of_service_configurations(self) -> Self {
        self.avg_config_value_of_service_configurations_as("avg_config_value_of_service_configurations", crate::Q::service_configurations().unlimited())
    }

    pub fn avg_config_value_of_service_configurations_as(self, alias: impl Into<String>, request: impl Into<QuerySelection>) -> Self {
        self.stats_from_service_configurations_as(alias, request.into().into_query().avg("config_value", "avg_config_value"))
    }
    pub fn standard_deviation_config_value_of_service_configurations(self) -> Self {
        self.standard_deviation_config_value_of_service_configurations_as("standard_deviation_config_value_of_service_configurations", crate::Q::service_configurations().unlimited())
    }

    pub fn standard_deviation_config_value_of_service_configurations_as(self, alias: impl Into<String>, request: impl Into<QuerySelection>) -> Self {
        self.stats_from_service_configurations_as(alias, request.into().into_query().stddev("config_value", "stdDev_config_value"))
    }
    pub fn square_root_of_population_standard_deviation_config_value_of_service_configurations(self) -> Self {
        self.square_root_of_population_standard_deviation_config_value_of_service_configurations_as("square_root_of_population_standard_deviation_config_value_of_service_configurations", crate::Q::service_configurations().unlimited())
    }

    pub fn square_root_of_population_standard_deviation_config_value_of_service_configurations_as(self, alias: impl Into<String>, request: impl Into<QuerySelection>) -> Self {
        self.stats_from_service_configurations_as(alias, request.into().into_query().stddev_pop("config_value", "stdDevPop_config_value"))
    }
    pub fn sample_variance_config_value_of_service_configurations(self) -> Self {
        self.sample_variance_config_value_of_service_configurations_as("sample_variance_config_value_of_service_configurations", crate::Q::service_configurations().unlimited())
    }

    pub fn sample_variance_config_value_of_service_configurations_as(self, alias: impl Into<String>, request: impl Into<QuerySelection>) -> Self {
        self.stats_from_service_configurations_as(alias, request.into().into_query().var_samp("config_value", "varSamp_config_value"))
    }
    pub fn sample_population_variance_config_value_of_service_configurations(self) -> Self {
        self.sample_population_variance_config_value_of_service_configurations_as("sample_population_variance_config_value_of_service_configurations", crate::Q::service_configurations().unlimited())
    }

    pub fn sample_population_variance_config_value_of_service_configurations_as(self, alias: impl Into<String>, request: impl Into<QuerySelection>) -> Self {
        self.stats_from_service_configurations_as(alias, request.into().into_query().var_pop("config_value", "varPop_config_value"))
    }
    pub fn min_create_time_of_service_configurations(self) -> Self {
        self.min_create_time_of_service_configurations_as("min_create_time_of_service_configurations", crate::Q::service_configurations().unlimited())
    }

    pub fn min_create_time_of_service_configurations_as(self, alias: impl Into<String>, request: impl Into<QuerySelection>) -> Self {
        self.stats_from_service_configurations_as(alias, request.into().into_query().min("create_time", "min_create_time"))
    }
    pub fn max_create_time_of_service_configurations(self) -> Self {
        self.max_create_time_of_service_configurations_as("max_create_time_of_service_configurations", crate::Q::service_configurations().unlimited())
    }

    pub fn max_create_time_of_service_configurations_as(self, alias: impl Into<String>, request: impl Into<QuerySelection>) -> Self {
        self.stats_from_service_configurations_as(alias, request.into().into_query().max("create_time", "max_create_time"))
    }
    pub fn min_update_time_of_service_configurations(self) -> Self {
        self.min_update_time_of_service_configurations_as("min_update_time_of_service_configurations", crate::Q::service_configurations().unlimited())
    }

    pub fn min_update_time_of_service_configurations_as(self, alias: impl Into<String>, request: impl Into<QuerySelection>) -> Self {
        self.stats_from_service_configurations_as(alias, request.into().into_query().min("update_time", "min_update_time"))
    }
    pub fn max_update_time_of_service_configurations(self) -> Self {
        self.max_update_time_of_service_configurations_as("max_update_time_of_service_configurations", crate::Q::service_configurations().unlimited())
    }

    pub fn max_update_time_of_service_configurations_as(self, alias: impl Into<String>, request: impl Into<QuerySelection>) -> Self {
        self.stats_from_service_configurations_as(alias, request.into().into_query().max("update_time", "max_update_time"))
    }

    pub fn count_pricing_rules(self) -> Self {
        self.count_pricing_rules_as("count_pricing_rules")
    }

    pub fn count_pricing_rules_as(self, alias: impl Into<String>) -> Self {
        self.count_pricing_rules_with(alias, crate::Q::pricing_rules().unlimited())
    }

    pub fn count_pricing_rules_with(mut self, alias: impl Into<String>, request: impl Into<QuerySelection>) -> Self {
        let selection = request.into();
        self.query_options.relation_aggregates.push(RelationAggregate::new(
            "pricing_rule_list",
            alias,
            selection,
            true,
        ));
        self
    }

    pub fn stats_from_pricing_rules(self, request: impl Into<QuerySelection>) -> Self {
        self.stats_from_pricing_rules_as("refinements", request)
    }

    pub fn stats_from_pricing_rules_as(mut self, alias: impl Into<String>, request: impl Into<QuerySelection>) -> Self {
        let selection = request.into();
        self.query_options.relation_aggregates.push(RelationAggregate::new(
            "pricing_rule_list",
            alias,
            selection,
            false,
        ));
        self
    }

    pub fn group_by_pricing_rules_with_details(self, request: impl Into<QuerySelection>) -> Self {
        self.stats_from_pricing_rules(request)
    }


    pub fn sum_value_of_pricing_rules(self) -> Self {
        self.sum_value_of_pricing_rules_as("sum_value_of_pricing_rules", crate::Q::pricing_rules().unlimited())
    }

    pub fn sum_value_of_pricing_rules_as(self, alias: impl Into<String>, request: impl Into<QuerySelection>) -> Self {
        self.stats_from_pricing_rules_as(alias, request.into().into_query().sum("value", "sum_value"))
    }
    pub fn min_value_of_pricing_rules(self) -> Self {
        self.min_value_of_pricing_rules_as("min_value_of_pricing_rules", crate::Q::pricing_rules().unlimited())
    }

    pub fn min_value_of_pricing_rules_as(self, alias: impl Into<String>, request: impl Into<QuerySelection>) -> Self {
        self.stats_from_pricing_rules_as(alias, request.into().into_query().min("value", "min_value"))
    }
    pub fn max_value_of_pricing_rules(self) -> Self {
        self.max_value_of_pricing_rules_as("max_value_of_pricing_rules", crate::Q::pricing_rules().unlimited())
    }

    pub fn max_value_of_pricing_rules_as(self, alias: impl Into<String>, request: impl Into<QuerySelection>) -> Self {
        self.stats_from_pricing_rules_as(alias, request.into().into_query().max("value", "max_value"))
    }
    pub fn avg_value_of_pricing_rules(self) -> Self {
        self.avg_value_of_pricing_rules_as("avg_value_of_pricing_rules", crate::Q::pricing_rules().unlimited())
    }

    pub fn avg_value_of_pricing_rules_as(self, alias: impl Into<String>, request: impl Into<QuerySelection>) -> Self {
        self.stats_from_pricing_rules_as(alias, request.into().into_query().avg("value", "avg_value"))
    }
    pub fn standard_deviation_value_of_pricing_rules(self) -> Self {
        self.standard_deviation_value_of_pricing_rules_as("standard_deviation_value_of_pricing_rules", crate::Q::pricing_rules().unlimited())
    }

    pub fn standard_deviation_value_of_pricing_rules_as(self, alias: impl Into<String>, request: impl Into<QuerySelection>) -> Self {
        self.stats_from_pricing_rules_as(alias, request.into().into_query().stddev("value", "stdDev_value"))
    }
    pub fn square_root_of_population_standard_deviation_value_of_pricing_rules(self) -> Self {
        self.square_root_of_population_standard_deviation_value_of_pricing_rules_as("square_root_of_population_standard_deviation_value_of_pricing_rules", crate::Q::pricing_rules().unlimited())
    }

    pub fn square_root_of_population_standard_deviation_value_of_pricing_rules_as(self, alias: impl Into<String>, request: impl Into<QuerySelection>) -> Self {
        self.stats_from_pricing_rules_as(alias, request.into().into_query().stddev_pop("value", "stdDevPop_value"))
    }
    pub fn sample_variance_value_of_pricing_rules(self) -> Self {
        self.sample_variance_value_of_pricing_rules_as("sample_variance_value_of_pricing_rules", crate::Q::pricing_rules().unlimited())
    }

    pub fn sample_variance_value_of_pricing_rules_as(self, alias: impl Into<String>, request: impl Into<QuerySelection>) -> Self {
        self.stats_from_pricing_rules_as(alias, request.into().into_query().var_samp("value", "varSamp_value"))
    }
    pub fn sample_population_variance_value_of_pricing_rules(self) -> Self {
        self.sample_population_variance_value_of_pricing_rules_as("sample_population_variance_value_of_pricing_rules", crate::Q::pricing_rules().unlimited())
    }

    pub fn sample_population_variance_value_of_pricing_rules_as(self, alias: impl Into<String>, request: impl Into<QuerySelection>) -> Self {
        self.stats_from_pricing_rules_as(alias, request.into().into_query().var_pop("value", "varPop_value"))
    }
    pub fn min_start_date_of_pricing_rules(self) -> Self {
        self.min_start_date_of_pricing_rules_as("min_start_date_of_pricing_rules", crate::Q::pricing_rules().unlimited())
    }

    pub fn min_start_date_of_pricing_rules_as(self, alias: impl Into<String>, request: impl Into<QuerySelection>) -> Self {
        self.stats_from_pricing_rules_as(alias, request.into().into_query().min("start_date", "min_start_date"))
    }
    pub fn max_start_date_of_pricing_rules(self) -> Self {
        self.max_start_date_of_pricing_rules_as("max_start_date_of_pricing_rules", crate::Q::pricing_rules().unlimited())
    }

    pub fn max_start_date_of_pricing_rules_as(self, alias: impl Into<String>, request: impl Into<QuerySelection>) -> Self {
        self.stats_from_pricing_rules_as(alias, request.into().into_query().max("start_date", "max_start_date"))
    }
    pub fn min_end_date_of_pricing_rules(self) -> Self {
        self.min_end_date_of_pricing_rules_as("min_end_date_of_pricing_rules", crate::Q::pricing_rules().unlimited())
    }

    pub fn min_end_date_of_pricing_rules_as(self, alias: impl Into<String>, request: impl Into<QuerySelection>) -> Self {
        self.stats_from_pricing_rules_as(alias, request.into().into_query().min("end_date", "min_end_date"))
    }
    pub fn max_end_date_of_pricing_rules(self) -> Self {
        self.max_end_date_of_pricing_rules_as("max_end_date_of_pricing_rules", crate::Q::pricing_rules().unlimited())
    }

    pub fn max_end_date_of_pricing_rules_as(self, alias: impl Into<String>, request: impl Into<QuerySelection>) -> Self {
        self.stats_from_pricing_rules_as(alias, request.into().into_query().max("end_date", "max_end_date"))
    }
    pub fn min_create_time_of_pricing_rules(self) -> Self {
        self.min_create_time_of_pricing_rules_as("min_create_time_of_pricing_rules", crate::Q::pricing_rules().unlimited())
    }

    pub fn min_create_time_of_pricing_rules_as(self, alias: impl Into<String>, request: impl Into<QuerySelection>) -> Self {
        self.stats_from_pricing_rules_as(alias, request.into().into_query().min("create_time", "min_create_time"))
    }
    pub fn max_create_time_of_pricing_rules(self) -> Self {
        self.max_create_time_of_pricing_rules_as("max_create_time_of_pricing_rules", crate::Q::pricing_rules().unlimited())
    }

    pub fn max_create_time_of_pricing_rules_as(self, alias: impl Into<String>, request: impl Into<QuerySelection>) -> Self {
        self.stats_from_pricing_rules_as(alias, request.into().into_query().max("create_time", "max_create_time"))
    }
    pub fn min_update_time_of_pricing_rules(self) -> Self {
        self.min_update_time_of_pricing_rules_as("min_update_time_of_pricing_rules", crate::Q::pricing_rules().unlimited())
    }

    pub fn min_update_time_of_pricing_rules_as(self, alias: impl Into<String>, request: impl Into<QuerySelection>) -> Self {
        self.stats_from_pricing_rules_as(alias, request.into().into_query().min("update_time", "min_update_time"))
    }
    pub fn max_update_time_of_pricing_rules(self) -> Self {
        self.max_update_time_of_pricing_rules_as("max_update_time_of_pricing_rules", crate::Q::pricing_rules().unlimited())
    }

    pub fn max_update_time_of_pricing_rules_as(self, alias: impl Into<String>, request: impl Into<QuerySelection>) -> Self {
        self.stats_from_pricing_rules_as(alias, request.into().into_query().max("update_time", "max_update_time"))
    }
}

impl<R> Default for ServiceRequest<R> {
    fn default() -> Self {
        Self::new()
    }
}

impl<R> From< ServiceRequest<R> > for SelectQuery {
    fn from(request: ServiceRequest<R>) -> Self {
        QuerySelection::from(request).into_query()
    }
}

impl<R> From< ServiceRequest<R> > for QuerySelection {
    fn from(request: ServiceRequest<R>) -> Self {
        Self {
            query: request.query,
            relation_selections: request.relation_selections,
            relation_filters: request.relation_filters,
            child_enhancements: request.child_enhancements,
            query_options: request.query_options,
        }
    }
}


impl<'a, C> crate::request_support::AuditedSave<'a, C> for teaql_core::Audited<crate::Service> 
where C: crate::request_support::TeaqlRepositoryProvider + ?Sized + 'a
{
    type Error = crate::TeaqlDataServiceError<C::ServiceRepository<'a>>;
    fn save(self, ctx: &'a C) -> std::pin::Pin<Box<dyn std::future::Future<Output = Result<teaql_runtime::GraphNode, Self::Error>> + '_>> {
        Box::pin(async move {
            teaql_runtime::save_audited_ledger_entity(self, ctx.user_context())
                .await
                .map_err(DataServiceError::Runtime)
        })
    }
}

impl<R: teaql_core::Entity> crate::PurposedQuery<ServiceRequest<R>> {
    pub fn new_entity<C>(&self, ctx: &C) -> crate::Service
    where
        C: crate::TeaqlRuntime + ?Sized,
    {
        crate::Service::runtime_new(ctx.user_context().entity_root())
    }

    fn into_inner_with_trace(mut self) -> ServiceRequest<R> {
        self.inner.query.trace_chain.push(teaql_core::TraceNode::new(
            self.inner.query.entity.clone(),
            None,
            self.purpose,
        ));
        self.inner
    }

    pub async fn execute_for_page<'a, C>(
        self,
        ctx: &'a C,
        offset: u64,
        limit: u64,
    ) -> Result<teaql_core::SmartList<R>, crate::request_support::TeaqlDataServiceError<C::ServiceRepository<'a>>>
    where
        C: crate::request_support::TeaqlRepositoryProvider + ?Sized,
    {
        self.into_inner_with_trace()._execute_for_page(ctx, offset, limit).await
    }

    pub async fn execute_for_exists<'a, C>(
        self,
        ctx: &'a C,
    ) -> Result<bool, crate::request_support::TeaqlDataServiceError<C::ServiceRepository<'a>>>
    where
        C: crate::request_support::TeaqlRepositoryProvider + ?Sized,
    {
        self.into_inner_with_trace()._execute_for_exists(ctx).await
    }

    pub async fn execute_for_list<'a, C>(self, ctx: &'a C) -> Result<teaql_core::SmartList<R>, crate::request_support::TeaqlDataServiceError<C::ServiceRepository<'a>>>
    where
        C: crate::request_support::TeaqlRepositoryProvider + ?Sized,
    {
        self.into_inner_with_trace()._execute_for_list(ctx).await
    }

    /// Execute query in streaming mode (chunked).
    /// Returns a Vec of StreamChunk, each containing up to chunk_size rows.
    /// Set chunk size via .stream(chunk_size) or .stream_default() on the query.
    pub async fn execute_for_stream<'a, C>(self, ctx: &'a C) -> Result<Vec<teaql_data_service::StreamChunk>, crate::request_support::TeaqlDataServiceError<C::ServiceRepository<'a>>>
    where
        C: crate::request_support::TeaqlRepositoryProvider + ?Sized,
    {
        self.into_inner_with_trace()._execute_for_stream(ctx).await
    }

    pub async fn execute_for_first<'a, C>(self, ctx: &'a C) -> Result<Option<R>, crate::request_support::TeaqlDataServiceError<C::ServiceRepository<'a>>>
    where
        C: crate::request_support::TeaqlRepositoryProvider + ?Sized,
    {
        self.into_inner_with_trace()._execute_for_first(ctx).await
    }

    pub async fn execute_for_one<'a, C>(self, ctx: &'a C) -> Result<Option<R>, crate::request_support::TeaqlDataServiceError<C::ServiceRepository<'a>>>
    where
        C: crate::request_support::TeaqlRepositoryProvider + ?Sized,
    {
        self.into_inner_with_trace()._execute_for_one(ctx).await
    }


    pub async fn execute_for_records<'a, C>(self, ctx: &'a C) -> Result<teaql_core::SmartList<teaql_core::Record>, crate::request_support::TeaqlDataServiceError<C::ServiceRepository<'a>>>
    where
        C: crate::request_support::TeaqlRepositoryProvider + ?Sized,
    {
        self.into_inner_with_trace()._execute_for_records(ctx).await
    }

    pub async fn execute_for_record<'a, C>(self, ctx: &'a C) -> Result<Option<teaql_core::Record>, crate::request_support::TeaqlDataServiceError<C::ServiceRepository<'a>>>
    where
        C: crate::request_support::TeaqlRepositoryProvider + ?Sized,
    {
        self.into_inner_with_trace()._execute_for_record(ctx).await
    }

    pub async fn execute_for_count<'a, C>(self, ctx: &'a C) -> Result<u64, crate::request_support::TeaqlDataServiceError<C::ServiceRepository<'a>>>
    where
        C: crate::request_support::TeaqlRepositoryProvider + ?Sized,
    {
        self.into_inner_with_trace()._execute_for_count(ctx).await
    }
}
