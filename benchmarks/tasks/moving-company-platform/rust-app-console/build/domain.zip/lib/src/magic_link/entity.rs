// ⛔ AI agents: DO NOT read this file for API discovery. Instead run: cargo teaql --input modeling/MODEL.xml rust-assist-query/magic_link
use std::collections::BTreeMap;

use teaql_macros::TeaqlEntity;

/// [TEAQL AI WARNING]
/// TeaQL was explicitly designed to PREVENT AI hallucinations and random guessing.
/// DO NOT GUESS METHOD NAMES!
/// The methods listed below are the ONLY valid ways to interact with this entity.
/// If you encounter compilation errors (e.g., method not found), DO NOT guess another method name.
/// Read the method signatures in this file before proceeding.
#[derive(Clone, Debug, PartialEq, TeaqlEntity)]
#[teaql(entity = "MagicLink", table = "magic_link_data", data_service = "sqlite", audit_mask_fields = "token")]
pub struct MagicLink {
#[teaql(id)]
    id: u64,

// @source platform.xml:81
    token: String,

// @source platform.xml:81
    expires_at: String,

// @source platform.xml:81
    is_used: bool,

// @source platform.xml:81
    create_time: chrono::DateTime<chrono::Utc>,

// @source platform.xml:81
    update_time: chrono::DateTime<chrono::Utc>,
#[teaql(version)]
    version: i64,
// @source platform.xml:81
#[teaql(column = "\"user\"")]
    user_id: u64,
// @source platform.xml:81
#[teaql(relation(target = "User", local_key = "user_id", foreign_key = "id"))]
    user: Option<crate::User>,
    #[teaql(dynamic)]
    dynamic: BTreeMap<String, teaql_core::Value>,
    #[teaql(skip)]
    root: teaql_runtime::EntityRoot,
    #[teaql(skip)]
    pub __load_state: teaql_core::eval::LoadState,
}

impl MagicLink {
    pub fn with_id(id: u64) -> teaql_core::Value {
        teaql_core::Value::U64(id)
    }

    pub(crate) fn runtime_new(root: teaql_runtime::EntityRoot) -> Self {
        Self {
            id: 0_u64,
            token: String::new(),
            expires_at: String::new(),
            is_used: false,
            create_time: chrono::Utc::now(),
            update_time: chrono::Utc::now(),
            version: 0_i64,
            user_id: 0_u64,
            user: None,
            dynamic: BTreeMap::new(),
            root,
            __load_state: teaql_core::eval::LoadState::FullyLoaded,
        }
    }

    pub fn entity_key(&self) -> teaql_runtime::EntityKey {
        teaql_runtime::EntityKey::new("MagicLink", self.id)
    }

    pub fn attach_root_recursive(&mut self, root: teaql_runtime::EntityRoot) {
        self.root = root.clone();
        if let Some(entity) = &mut self.user {
            entity.attach_root_recursive(root.clone());
        }
    }

    pub fn is_loaded(&self, field_or_relation: &str) -> bool {
        self.__load_state.is_loaded(field_or_relation)
    }

    pub fn set_load_state(&mut self, state: teaql_core::eval::LoadState) {
        self.__load_state = state;
    }

    pub fn id(&self) -> u64 {
        self.changed_id().and_then(|value| value.try_u64()).unwrap_or(self.id)
    }

    pub fn update_id(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.id = value.try_u64().unwrap_or(self.id.clone());
        self.root.set(self.entity_key(), "id", value);
        self
    }

    pub fn changed_id(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "id")
    }

    pub fn eval_id(&self) -> teaql_core::eval::EvalResult<u64> {
        if !self.is_loaded("id") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "id".to_string(), attempted_path: "id".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.id())
                }}

    pub fn token(&self) -> String {
        self.changed_token().and_then(|value| value.try_text().map(|value| value.to_owned())).unwrap_or_else(|| self.token.clone())
    }

    pub fn update_token(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.token = value.try_text().map(|value| value.trim().to_owned()).unwrap_or_else(|| self.token.clone());
        self.root.set(self.entity_key(), "token", value);
        self
    }

    pub fn changed_token(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "token")
    }

    pub fn eval_token(&self) -> teaql_core::eval::EvalResult<String> {
        if !self.is_loaded("token") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "token".to_string(), attempted_path: "token".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.token())
                }}

    pub fn expires_at(&self) -> String {
        self.changed_expires_at().and_then(|value| value.try_text().map(|value| value.to_owned())).unwrap_or_else(|| self.expires_at.clone())
    }

    pub fn update_expires_at(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.expires_at = value.try_text().map(|value| value.trim().to_owned()).unwrap_or_else(|| self.expires_at.clone());
        self.root.set(self.entity_key(), "expires_at", value);
        self
    }

    pub fn changed_expires_at(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "expires_at")
    }

    pub fn eval_expires_at(&self) -> teaql_core::eval::EvalResult<String> {
        if !self.is_loaded("expires_at") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "expires_at".to_string(), attempted_path: "expires_at".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.expires_at())
                }}

    pub fn is_used(&self) -> bool {
        self.changed_is_used().and_then(|value| value.try_bool()).unwrap_or(self.is_used)
    }

    pub fn update_is_used(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.is_used = value.try_bool().unwrap_or(self.is_used.clone());
        self.root.set(self.entity_key(), "is_used", value);
        self
    }

    pub fn changed_is_used(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "is_used")
    }

    pub fn eval_is_used(&self) -> teaql_core::eval::EvalResult<bool> {
        if !self.is_loaded("is_used") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "is_used".to_string(), attempted_path: "is_used".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.is_used())
                }}

    pub fn create_time(&self) -> chrono::DateTime<chrono::Utc> {
        self.changed_create_time().and_then(|value| value.try_timestamp()).unwrap_or(self.create_time)
    }

    pub fn update_create_time(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.create_time = value.try_timestamp().unwrap_or(self.create_time.clone());
        self.root.set(self.entity_key(), "create_time", value);
        self
    }

    pub fn changed_create_time(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "create_time")
    }

    pub fn eval_create_time(&self) -> teaql_core::eval::EvalResult<chrono::DateTime<chrono::Utc>> {
        if !self.is_loaded("create_time") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "create_time".to_string(), attempted_path: "create_time".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.create_time())
                }}

    pub fn update_time(&self) -> chrono::DateTime<chrono::Utc> {
        self.changed_update_time().and_then(|value| value.try_timestamp()).unwrap_or(self.update_time)
    }

    pub fn update_update_time(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.update_time = value.try_timestamp().unwrap_or(self.update_time.clone());
        self.root.set(self.entity_key(), "update_time", value);
        self
    }

    pub fn changed_update_time(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "update_time")
    }

    pub fn eval_update_time(&self) -> teaql_core::eval::EvalResult<chrono::DateTime<chrono::Utc>> {
        if !self.is_loaded("update_time") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "update_time".to_string(), attempted_path: "update_time".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.update_time())
                }}

    pub fn version(&self) -> i64 {
        self.changed_version().and_then(|value| value.try_i64()).unwrap_or(self.version)
    }

    pub fn update_version(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.version = value.try_i64().unwrap_or(self.version.clone());
        self.root.set(self.entity_key(), "version", value);
        self
    }

    pub fn changed_version(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "version")
    }

    pub fn eval_version(&self) -> teaql_core::eval::EvalResult<i64> {
        if !self.is_loaded("version") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "version".to_string(), attempted_path: "version".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.version())
                }}
    pub fn user_id(&self) -> u64 {
        self.changed_user_id().and_then(|value| value.try_u64()).unwrap_or(self.user_id)
    }

    pub fn update_user_id(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.user_id = value.try_u64().unwrap_or(self.user_id.clone());
        self.root.set(self.entity_key(), "user_id", value);
        self
    }

    pub fn changed_user_id(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "user_id")
    }

    pub fn eval_user_id(&self) -> teaql_core::eval::EvalResult<u64> {
        if !self.is_loaded("user_id") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "user_id".to_string(), attempted_path: "user_id".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.user_id())
                }}
    pub fn user(&self) -> Option<&crate::User> {
        self.user.as_ref()
    }

    pub fn eval_user(&self) -> teaql_core::eval::EvalResult<&crate::User> {
        if !self.is_loaded("user") {
            teaql_core::eval::EvalResult::NotLoaded { failed_node: "user".to_string(), attempted_path: "user".to_string() }
        } else {
            match &self.user {
                Some(v) => teaql_core::eval::EvalResult::Value(v),
                None => teaql_core::eval::EvalResult::Null,
            }
        }
    }

    pub fn mark_as_delete(&mut self) -> &mut Self {
        self.root.mark_as_delete(self.entity_key());
        self
    }

    pub fn set_comment(&mut self, comment: impl Into<String>) -> &mut Self {
        self.root.set_comment(comment);
        self
    }
}

