#[derive(Clone)]
pub struct PayrollCalculationExpression<'a> {
    result: teaql_core::eval::EvalResult<&'a crate::PayrollCalculation>,
    root_desc: std::sync::Arc<String>,
}

impl<'a> PayrollCalculationExpression<'a> {
    pub fn new(result: teaql_core::eval::EvalResult<&'a crate::PayrollCalculation>, root_desc: std::sync::Arc<String>) -> Self {
        Self { result, root_desc }
    }

    fn resolve(&self) -> Option<&'a crate::PayrollCalculation> {
        match &self.result {
            teaql_core::eval::EvalResult::Value(v) => Some(*v),
            teaql_core::eval::EvalResult::Null => None,
            teaql_core::eval::EvalResult::NotLoaded { failed_node, attempted_path } => {
                crate::trigger_logic_bug_panic(&self.root_desc, &failed_node, &attempted_path)
            }
        }
    }

    pub fn eval(&self) -> Option<&'a crate::PayrollCalculation> {
        self.resolve()
    }

    pub fn unwrap(&self) -> &'a crate::PayrollCalculation {
        self.resolve().expect("Relation was legitimately null in database!")
    }

    pub fn get_id(self) -> crate::ValueExpression<'a, u64> {
        let next = self.result.and_then("id", |entity| entity.eval_id());
        crate::ValueExpression::new(next, self.root_desc.clone())
    }

    pub fn get_period_start(self) -> crate::ValueExpression<'a, chrono::NaiveDate> {
        let next = self.result.and_then("period_start", |entity| entity.eval_period_start());
        crate::ValueExpression::new(next, self.root_desc.clone())
    }

    pub fn get_period_end(self) -> crate::ValueExpression<'a, chrono::NaiveDate> {
        let next = self.result.and_then("period_end", |entity| entity.eval_period_end());
        crate::ValueExpression::new(next, self.root_desc.clone())
    }

    pub fn get_regular_hours(self) -> crate::ValueExpression<'a, rust_decimal::Decimal> {
        let next = self.result.and_then("regular_hours", |entity| entity.eval_regular_hours());
        crate::ValueExpression::new(next, self.root_desc.clone())
    }

    pub fn get_overtime_hours(self) -> crate::ValueExpression<'a, rust_decimal::Decimal> {
        let next = self.result.and_then("overtime_hours", |entity| entity.eval_overtime_hours());
        crate::ValueExpression::new(next, self.root_desc.clone())
    }

    pub fn get_hourly_rate(self) -> crate::ValueExpression<'a, rust_decimal::Decimal> {
        let next = self.result.and_then("hourly_rate", |entity| entity.eval_hourly_rate());
        crate::ValueExpression::new(next, self.root_desc.clone())
    }

    pub fn get_gross_pay(self) -> crate::ValueExpression<'a, rust_decimal::Decimal> {
        let next = self.result.and_then("gross_pay", |entity| entity.eval_gross_pay());
        crate::ValueExpression::new(next, self.root_desc.clone())
    }

    pub fn get_deductions(self) -> crate::ValueExpression<'a, rust_decimal::Decimal> {
        let next = self.result.and_then("deductions", |entity| entity.eval_deductions());
        crate::ValueExpression::new(next, self.root_desc.clone())
    }

    pub fn get_net_pay(self) -> crate::ValueExpression<'a, rust_decimal::Decimal> {
        let next = self.result.and_then("net_pay", |entity| entity.eval_net_pay());
        crate::ValueExpression::new(next, self.root_desc.clone())
    }

    pub fn get_create_time(self) -> crate::ValueExpression<'a, chrono::DateTime<chrono::Utc>> {
        let next = self.result.and_then("create_time", |entity| entity.eval_create_time());
        crate::ValueExpression::new(next, self.root_desc.clone())
    }

    pub fn get_update_time(self) -> crate::ValueExpression<'a, chrono::DateTime<chrono::Utc>> {
        let next = self.result.and_then("update_time", |entity| entity.eval_update_time());
        crate::ValueExpression::new(next, self.root_desc.clone())
    }

    pub fn get_version(self) -> crate::ValueExpression<'a, i64> {
        let next = self.result.and_then("version", |entity| entity.eval_version());
        crate::ValueExpression::new(next, self.root_desc.clone())
    }
    pub fn get_employee_id(self) -> crate::ValueExpression<'a, u64> {
        let next = self.result.and_then("employee_id", |entity| entity.eval_employee_id());
        crate::ValueExpression::new(next, self.root_desc.clone())
    }
    pub fn get_employee(self) -> crate::EmployeeExpression<'a> {
        let next = self.result.and_then("employee", |entity| entity.eval_employee());
        crate::EmployeeExpression::new(next, self.root_desc.clone())
    }
}

#[derive(Clone)]
pub struct PayrollCalculationListExpression<'a> {
    result: teaql_core::eval::EvalResult<&'a teaql_core::SmartList<crate::PayrollCalculation>>,
    root_desc: std::sync::Arc<String>,
}

impl<'a> PayrollCalculationListExpression<'a> {
    pub fn new(result: teaql_core::eval::EvalResult<&'a teaql_core::SmartList<crate::PayrollCalculation>>, root_desc: std::sync::Arc<String>) -> Self {
        Self { result, root_desc }
    }

    fn resolve(&self) -> Option<&'a teaql_core::SmartList<crate::PayrollCalculation>> {
        match &self.result {
            teaql_core::eval::EvalResult::Value(v) => Some(*v),
            teaql_core::eval::EvalResult::Null => None,
            teaql_core::eval::EvalResult::NotLoaded { failed_node, attempted_path } => {
                crate::trigger_logic_bug_panic(&self.root_desc, &failed_node, &attempted_path)
            }
        }
    }

    pub fn eval(&self) -> Option<&'a teaql_core::SmartList<crate::PayrollCalculation>> {
        self.resolve()
    }

    pub fn unwrap(&self) -> &'a teaql_core::SmartList<crate::PayrollCalculation> {
        self.resolve().expect("List relation was legitimately null in database!")
    }

    pub fn size(&self) -> crate::ValueExpression<'a, usize> {
        let next = self.result.clone().and_then("size", |list| teaql_core::eval::EvalResult::Value(list.len()));
        crate::ValueExpression::new(next, self.root_desc.clone())
    }

    pub fn first(&self) -> crate::PayrollCalculationExpression<'a> {
        let next = self.result.clone().and_then("first", |list| {
            if let Some(item) = list.first() {
                teaql_core::eval::EvalResult::Value(item)
            } else {
                teaql_core::eval::EvalResult::Null
            }
        });
        crate::PayrollCalculationExpression::new(next, self.root_desc.clone())
    }

    pub fn get(&self, index: usize) -> crate::PayrollCalculationExpression<'a> {
        let next = self.result.clone().and_then("get", |list| {
            if let Some(item) = list.get(index) {
                teaql_core::eval::EvalResult::Value(item)
            } else {
                teaql_core::eval::EvalResult::Null
            }
        });
        crate::PayrollCalculationExpression::new(next, self.root_desc.clone())
    }
}