// ⛔ AI agents: DO NOT read this file for API discovery. Instead run: cargo teaql --input modeling/MODEL.xml rust-assist-query/pricing_rule
use std::collections::BTreeMap;

use teaql_macros::TeaqlEntity;

/// [TEAQL AI WARNING]
/// TeaQL was explicitly designed to PREVENT AI hallucinations and random guessing.
/// DO NOT GUESS METHOD NAMES!
/// The methods listed below are the ONLY valid ways to interact with this entity.
/// If you encounter compilation errors (e.g., method not found), DO NOT guess another method name.
/// Read the method signatures in this file before proceeding.
#[derive(Clone, Debug, PartialEq, TeaqlEntity)]
#[teaql(entity = "PricingRule", table = "pricing_rule_data", data_service = "sqlite")]
pub struct PricingRule {
#[teaql(id)]
    id: u64,

// @source products.xml:61
    rule_name: String,

// @source products.xml:61
    rule_type: String,

// @source products.xml:61
    value: rust_decimal::Decimal,

// @source products.xml:61
    start_date: chrono::NaiveDate,

// @source products.xml:61
    end_date: chrono::NaiveDate,

// @source products.xml:61
    is_active: bool,

// @source products.xml:61
    create_time: chrono::DateTime<chrono::Utc>,

// @source products.xml:61
    update_time: chrono::DateTime<chrono::Utc>,
#[teaql(version)]
    version: i64,
// @source products.xml:61
#[teaql(column = "service")]
    service_id: u64,
// @source products.xml:61
#[teaql(relation(target = "Service", local_key = "service_id", foreign_key = "id"))]
    service: Option<crate::Service>,
    #[teaql(dynamic)]
    dynamic: BTreeMap<String, teaql_core::Value>,
    #[teaql(skip)]
    root: teaql_runtime::EntityRoot,
    #[teaql(skip)]
    pub __load_state: teaql_core::eval::LoadState,
}

impl PricingRule {
    pub fn with_id(id: u64) -> teaql_core::Value {
        teaql_core::Value::U64(id)
    }

    pub(crate) fn runtime_new(root: teaql_runtime::EntityRoot) -> Self {
        Self {
            id: 0_u64,
            rule_name: String::new(),
            rule_type: String::new(),
            value: rust_decimal::Decimal::ZERO,
            start_date: chrono::NaiveDate::from_ymd_opt(1970, 1, 1).unwrap(),
            end_date: chrono::NaiveDate::from_ymd_opt(1970, 1, 1).unwrap(),
            is_active: false,
            create_time: chrono::Utc::now(),
            update_time: chrono::Utc::now(),
            version: 0_i64,
            service_id: 0_u64,
            service: None,
            dynamic: BTreeMap::new(),
            root,
            __load_state: teaql_core::eval::LoadState::FullyLoaded,
        }
    }

    pub fn entity_key(&self) -> teaql_runtime::EntityKey {
        teaql_runtime::EntityKey::new("PricingRule", self.id)
    }

    pub fn attach_root_recursive(&mut self, root: teaql_runtime::EntityRoot) {
        self.root = root.clone();
        if let Some(entity) = &mut self.service {
            entity.attach_root_recursive(root.clone());
        }
    }

    pub fn is_loaded(&self, field_or_relation: &str) -> bool {
        self.__load_state.is_loaded(field_or_relation)
    }

    pub fn set_load_state(&mut self, state: teaql_core::eval::LoadState) {
        self.__load_state = state;
    }

    pub fn id(&self) -> u64 {
        self.changed_id().and_then(|value| value.try_u64()).unwrap_or(self.id)
    }

    pub fn update_id(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.id = value.try_u64().unwrap_or(self.id.clone());
        self.root.set(self.entity_key(), "id", value);
        self
    }

    pub fn changed_id(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "id")
    }

    pub fn eval_id(&self) -> teaql_core::eval::EvalResult<u64> {
        if !self.is_loaded("id") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "id".to_string(), attempted_path: "id".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.id())
                }}

    pub fn rule_name(&self) -> String {
        self.changed_rule_name().and_then(|value| value.try_text().map(|value| value.to_owned())).unwrap_or_else(|| self.rule_name.clone())
    }

    pub fn update_rule_name(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.rule_name = value.try_text().map(|value| value.trim().to_owned()).unwrap_or_else(|| self.rule_name.clone());
        self.root.set(self.entity_key(), "rule_name", value);
        self
    }

    pub fn changed_rule_name(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "rule_name")
    }

    pub fn eval_rule_name(&self) -> teaql_core::eval::EvalResult<String> {
        if !self.is_loaded("rule_name") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "rule_name".to_string(), attempted_path: "rule_name".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.rule_name())
                }}

    pub fn rule_type(&self) -> String {
        self.changed_rule_type().and_then(|value| value.try_text().map(|value| value.to_owned())).unwrap_or_else(|| self.rule_type.clone())
    }

    pub fn update_rule_type(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.rule_type = value.try_text().map(|value| value.trim().to_owned()).unwrap_or_else(|| self.rule_type.clone());
        self.root.set(self.entity_key(), "rule_type", value);
        self
    }

    pub fn changed_rule_type(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "rule_type")
    }

    pub fn eval_rule_type(&self) -> teaql_core::eval::EvalResult<String> {
        if !self.is_loaded("rule_type") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "rule_type".to_string(), attempted_path: "rule_type".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.rule_type())
                }}

    pub fn value(&self) -> rust_decimal::Decimal {
        self.changed_value().and_then(|value| value.try_decimal()).unwrap_or(self.value)
    }

    pub fn update_value(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.value = value.try_decimal().unwrap_or(self.value.clone());
        self.root.set(self.entity_key(), "value", value);
        self
    }

    pub fn changed_value(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "value")
    }

    pub fn eval_value(&self) -> teaql_core::eval::EvalResult<rust_decimal::Decimal> {
        if !self.is_loaded("value") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "value".to_string(), attempted_path: "value".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.value())
                }}

    pub fn start_date(&self) -> chrono::NaiveDate {
        self.changed_start_date().and_then(|value| value.try_date()).unwrap_or(self.start_date)
    }

    pub fn update_start_date(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.start_date = value.try_date().unwrap_or(self.start_date.clone());
        self.root.set(self.entity_key(), "start_date", value);
        self
    }

    pub fn changed_start_date(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "start_date")
    }

    pub fn eval_start_date(&self) -> teaql_core::eval::EvalResult<chrono::NaiveDate> {
        if !self.is_loaded("start_date") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "start_date".to_string(), attempted_path: "start_date".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.start_date())
                }}

    pub fn end_date(&self) -> chrono::NaiveDate {
        self.changed_end_date().and_then(|value| value.try_date()).unwrap_or(self.end_date)
    }

    pub fn update_end_date(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.end_date = value.try_date().unwrap_or(self.end_date.clone());
        self.root.set(self.entity_key(), "end_date", value);
        self
    }

    pub fn changed_end_date(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "end_date")
    }

    pub fn eval_end_date(&self) -> teaql_core::eval::EvalResult<chrono::NaiveDate> {
        if !self.is_loaded("end_date") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "end_date".to_string(), attempted_path: "end_date".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.end_date())
                }}

    pub fn is_active(&self) -> bool {
        self.changed_is_active().and_then(|value| value.try_bool()).unwrap_or(self.is_active)
    }

    pub fn update_is_active(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.is_active = value.try_bool().unwrap_or(self.is_active.clone());
        self.root.set(self.entity_key(), "is_active", value);
        self
    }

    pub fn changed_is_active(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "is_active")
    }

    pub fn eval_is_active(&self) -> teaql_core::eval::EvalResult<bool> {
        if !self.is_loaded("is_active") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "is_active".to_string(), attempted_path: "is_active".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.is_active())
                }}

    pub fn create_time(&self) -> chrono::DateTime<chrono::Utc> {
        self.changed_create_time().and_then(|value| value.try_timestamp()).unwrap_or(self.create_time)
    }

    pub fn update_create_time(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.create_time = value.try_timestamp().unwrap_or(self.create_time.clone());
        self.root.set(self.entity_key(), "create_time", value);
        self
    }

    pub fn changed_create_time(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "create_time")
    }

    pub fn eval_create_time(&self) -> teaql_core::eval::EvalResult<chrono::DateTime<chrono::Utc>> {
        if !self.is_loaded("create_time") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "create_time".to_string(), attempted_path: "create_time".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.create_time())
                }}

    pub fn update_time(&self) -> chrono::DateTime<chrono::Utc> {
        self.changed_update_time().and_then(|value| value.try_timestamp()).unwrap_or(self.update_time)
    }

    pub fn update_update_time(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.update_time = value.try_timestamp().unwrap_or(self.update_time.clone());
        self.root.set(self.entity_key(), "update_time", value);
        self
    }

    pub fn changed_update_time(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "update_time")
    }

    pub fn eval_update_time(&self) -> teaql_core::eval::EvalResult<chrono::DateTime<chrono::Utc>> {
        if !self.is_loaded("update_time") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "update_time".to_string(), attempted_path: "update_time".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.update_time())
                }}

    pub fn version(&self) -> i64 {
        self.changed_version().and_then(|value| value.try_i64()).unwrap_or(self.version)
    }

    pub fn update_version(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.version = value.try_i64().unwrap_or(self.version.clone());
        self.root.set(self.entity_key(), "version", value);
        self
    }

    pub fn changed_version(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "version")
    }

    pub fn eval_version(&self) -> teaql_core::eval::EvalResult<i64> {
        if !self.is_loaded("version") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "version".to_string(), attempted_path: "version".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.version())
                }}
    pub fn service_id(&self) -> u64 {
        self.changed_service_id().and_then(|value| value.try_u64()).unwrap_or(self.service_id)
    }

    pub fn update_service_id(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.service_id = value.try_u64().unwrap_or(self.service_id.clone());
        self.root.set(self.entity_key(), "service_id", value);
        self
    }

    pub fn changed_service_id(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "service_id")
    }

    pub fn eval_service_id(&self) -> teaql_core::eval::EvalResult<u64> {
        if !self.is_loaded("service_id") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "service_id".to_string(), attempted_path: "service_id".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.service_id())
                }}
    pub fn service(&self) -> Option<&crate::Service> {
        self.service.as_ref()
    }

    pub fn eval_service(&self) -> teaql_core::eval::EvalResult<&crate::Service> {
        if !self.is_loaded("service") {
            teaql_core::eval::EvalResult::NotLoaded { failed_node: "service".to_string(), attempted_path: "service".to_string() }
        } else {
            match &self.service {
                Some(v) => teaql_core::eval::EvalResult::Value(v),
                None => teaql_core::eval::EvalResult::Null,
            }
        }
    }

    pub fn mark_as_delete(&mut self) -> &mut Self {
        self.root.mark_as_delete(self.entity_key());
        self
    }

    pub fn set_comment(&mut self, comment: impl Into<String>) -> &mut Self {
        self.root.set_comment(comment);
        self
    }
}

