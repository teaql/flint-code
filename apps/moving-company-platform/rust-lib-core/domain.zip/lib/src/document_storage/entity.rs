
// ⛔ AI agents: DO NOT read this file for API discovery. Instead run: cargo teaql --input modeling/MODEL.xml rust-assist-query/document_storage
use std::collections::BTreeMap;

use teaql_macros::TeaqlEntity;

/// [TEAQL AI WARNING]
/// TeaQL was explicitly designed to PREVENT AI hallucinations and random guessing.
/// DO NOT GUESS METHOD NAMES!
/// The methods listed below are the ONLY valid ways to interact with this entity.
/// If you encounter compilation errors (e.g., method not found), DO NOT guess another method name.
/// Read the method signatures in this file before proceeding.
#[derive(Clone, Debug, PartialEq, TeaqlEntity)]
#[teaql(entity = "DocumentStorage", table = "document_storage_data", data_service = "sqlite")]
pub struct DocumentStorage {
#[teaql(id)]
    id: u64,

// @source moving-company.xml:48
    document_url: String,

// @source moving-company.xml:48
    document_name: String,

// @source moving-company.xml:48
    create_time: teaql_core::time::Timestamp,

// @source moving-company.xml:48
    update_time: teaql_core::time::Timestamp,
#[teaql(version)]
    version: i64,
// @source moving-company.xml:48
#[teaql(column = "user_account")]
    user_account_id: u64,
// @source moving-company.xml:48
#[teaql(relation(target = "UserAccount", local_key = "user_account_id", foreign_key = "id"))]
    user_account: Option<crate::UserAccount>,
    #[teaql(dynamic)]
    dynamic: BTreeMap<String, teaql_core::Value>,
    #[teaql(skip)]
    root: teaql_runtime::EntityRoot,
    #[teaql(skip)]
    pub __load_state: teaql_core::eval::LoadState,
}

impl DocumentStorage {
    pub const ENTITY_NAME: &'static str = "Document Storage";

    pub fn with_id(id: u64) -> teaql_core::Value {
        teaql_core::Value::U64(id)
    }

    pub(crate) fn runtime_new(root: teaql_runtime::EntityRoot) -> Self {
        Self {
            id: 0_u64,
            document_url: String::new(),
            document_name: String::new(),
            create_time: teaql_core::time::Timestamp::now(),
            update_time: teaql_core::time::Timestamp::now(),
            version: 0_i64,
            user_account_id: 0_u64,
            user_account: None,
            dynamic: BTreeMap::new(),
            root,
            __load_state: teaql_core::eval::LoadState::FullyLoaded,
        }
    }

    pub fn entity_key(&self) -> teaql_runtime::EntityKey {
        teaql_runtime::EntityKey::new("DocumentStorage", self.id)
    }

    pub fn attach_root_recursive(&mut self, root: teaql_runtime::EntityRoot) {
        self.root = root.clone();
        if let Some(entity) = &mut self.user_account {
            entity.attach_root_recursive(root.clone());
        }
    }

    pub fn is_loaded(&self, field_or_relation: &str) -> bool {
        self.__load_state.is_loaded(field_or_relation)
    }

    pub fn set_load_state(&mut self, state: teaql_core::eval::LoadState) {
        self.__load_state = state;
    }

    pub fn id(&self) -> u64 {
        self.changed_id().and_then(|value| value.try_u64()).unwrap_or(self.id)
    }

    pub fn update_id(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.id = value.try_u64().unwrap_or(self.id.clone());
        self.root.set(self.entity_key(), "id", value);
        self
    }

    pub fn changed_id(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "id")
    }

    pub fn eval_id(&self) -> teaql_core::eval::EvalResult<u64> {
        if !self.is_loaded("id") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "id".to_string(), attempted_path: "id".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.id())
                }}

    pub fn document_url(&self) -> String {
        self.changed_document_url().and_then(|value| value.try_text().map(|value| value.to_owned())).unwrap_or_else(|| self.document_url.clone())
    }

    pub fn update_document_url(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.document_url = value.try_text().map(|value| value.trim().to_owned()).unwrap_or_else(|| self.document_url.clone());
        self.root.set(self.entity_key(), "document_url", value);
        self
    }

    pub fn changed_document_url(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "document_url")
    }

    pub fn eval_document_url(&self) -> teaql_core::eval::EvalResult<String> {
        if !self.is_loaded("document_url") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "document_url".to_string(), attempted_path: "document_url".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.document_url())
                }}

    pub fn document_name(&self) -> String {
        self.changed_document_name().and_then(|value| value.try_text().map(|value| value.to_owned())).unwrap_or_else(|| self.document_name.clone())
    }

    pub fn update_document_name(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.document_name = value.try_text().map(|value| value.trim().to_owned()).unwrap_or_else(|| self.document_name.clone());
        self.root.set(self.entity_key(), "document_name", value);
        self
    }

    pub fn changed_document_name(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "document_name")
    }

    pub fn eval_document_name(&self) -> teaql_core::eval::EvalResult<String> {
        if !self.is_loaded("document_name") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "document_name".to_string(), attempted_path: "document_name".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.document_name())
                }}

    pub fn create_time(&self) -> teaql_core::time::Timestamp {
        self.changed_create_time().and_then(|value| value.try_timestamp()).unwrap_or(self.create_time)
    }

    pub fn update_create_time(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.create_time = value.try_timestamp().unwrap_or(self.create_time.clone());
        self.root.set(self.entity_key(), "create_time", value);
        self
    }

    pub fn changed_create_time(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "create_time")
    }

    pub fn eval_create_time(&self) -> teaql_core::eval::EvalResult<teaql_core::time::Timestamp> {
        if !self.is_loaded("create_time") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "create_time".to_string(), attempted_path: "create_time".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.create_time())
                }}

    pub fn update_time(&self) -> teaql_core::time::Timestamp {
        self.changed_update_time().and_then(|value| value.try_timestamp()).unwrap_or(self.update_time)
    }

    pub fn update_update_time(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.update_time = value.try_timestamp().unwrap_or(self.update_time.clone());
        self.root.set(self.entity_key(), "update_time", value);
        self
    }

    pub fn changed_update_time(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "update_time")
    }

    pub fn eval_update_time(&self) -> teaql_core::eval::EvalResult<teaql_core::time::Timestamp> {
        if !self.is_loaded("update_time") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "update_time".to_string(), attempted_path: "update_time".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.update_time())
                }}

    pub fn version(&self) -> i64 {
        self.changed_version().and_then(|value| value.try_i64()).unwrap_or(self.version)
    }

    pub fn update_version(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.version = value.try_i64().unwrap_or(self.version.clone());
        self.root.set(self.entity_key(), "version", value);
        self
    }

    pub fn changed_version(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "version")
    }

    pub fn eval_version(&self) -> teaql_core::eval::EvalResult<i64> {
        if !self.is_loaded("version") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "version".to_string(), attempted_path: "version".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.version())
                }}
    pub fn user_account_id(&self) -> u64 {
        self.changed_user_account_id().and_then(|value| value.try_u64()).unwrap_or(self.user_account_id)
    }

    pub fn update_user_account_id(&mut self, value: impl Into<teaql_core::Value>) -> &mut Self {
        let value = value.into();
        self.user_account_id = value.try_u64().unwrap_or(self.user_account_id.clone());
        self.root.set(self.entity_key(), "user_account_id", value);
        self
    }

    pub fn changed_user_account_id(&self) -> Option<teaql_core::Value> {
        self.root.get(&self.entity_key(), "user_account_id")
    }

    pub fn eval_user_account_id(&self) -> teaql_core::eval::EvalResult<u64> {
        if !self.is_loaded("user_account_id") {
                    teaql_core::eval::EvalResult::NotLoaded { failed_node: "user_account_id".to_string(), attempted_path: "user_account_id".to_string() }
                } else {
                    teaql_core::eval::EvalResult::Value(self.user_account_id())
                }}
    pub fn user_account(&self) -> Option<&crate::UserAccount> {
        self.user_account.as_ref()
    }

    pub fn eval_user_account(&self) -> teaql_core::eval::EvalResult<&crate::UserAccount> {
        if !self.is_loaded("user_account") {
            teaql_core::eval::EvalResult::NotLoaded { failed_node: "user_account".to_string(), attempted_path: "user_account".to_string() }
        } else {
            match &self.user_account {
                Some(v) => teaql_core::eval::EvalResult::Value(v),
                None => teaql_core::eval::EvalResult::Null,
            }
        }
    }

    pub fn mark_as_delete(&mut self) -> &mut Self {
        self.root.mark_as_delete(self.entity_key());
        self
    }

    pub fn set_comment(&mut self, comment: impl Into<String>) -> &mut Self {
        self.root.set_comment(comment);
        self
    }
}

